    jQuery(document).ready(function() {
        jQuery("div.lazy").lazy({
            effect: "fadeIn",
            effectTime: 400  //In milliseconds
        });
        
        jQuery("img.lazy").lazy({
            effect: "fadeIn",
            effectTime: 400  //In milliseconds                
        });                                  
    });
    wow = new WOW({
        animateClass: 'animated',
        offset: 100
    });
    wow.init();
    
    jQuery(window).load(function() { // makes sure the whole site is loaded
        $('#status').fadeOut(); // will first fade out the loading animation
        $('#preloader').delay(100).fadeOut('slow'); // will fade out the white DIV that covers the website.
        $('body').delay(100).css({
            'overflow': 'visible'
        });
    })
    function print_text(url) {
        newwindow=window.open(url,'name','height=auto,width=800');
        if (window.focus) {newwindow.focus()}
        return false;
    }        	
    $(window).scroll(function(){
        if($(this).scrollTop()>123){
        $('#goto_top').fadeIn(1000);
        }else{
            $('#goto_top').fadeOut(1000);
        }
    });       