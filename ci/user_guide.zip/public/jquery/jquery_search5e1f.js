jQuery(document).ready(function() {
//$(document).ready(function() {
    $(".btn_search_sm").click(function(){
            $(".form_search_sm").slideToggle();
    });
    $(".btn_search_pc").click(function(){
            $(".form_search_pc").slideToggle();
    });
    $(".btn_menu_sm").click(function(){
        $(".menu_device").slideToggle({
            //bottom: "toggle"
            //alert("Hello");
        });
    }); 
    
	$("#content .block_tap").hide(); // Initially hide all content
	$("#tabs li:first").attr("id","current"); // Activate first tab
	$("#content .block_tap:first").fadeIn(); // Show first tab content                
    $('#tabs a').click(function(e) {
        e.preventDefault();        
        $("#content .block_tap").hide(); //Hide all content
        $("#tabs li").attr("id",""); //Reset id's
        $(this).parent().attr("id","current"); // Activate this
        $('#' + $(this).attr('title')).fadeIn(); // Show content for current tab
    });
    
    $(".block_slide_hote" ).show(1);
    jQuery('#newsslider').accessNews({});  
    
    var time_sc=100;
    $(window).scroll(function(){
        if($(this).scrollTop()>176){
            if(time_sc==1){
                $("#fixed_menu").addClass("fixed_topmenu");
                $("#hotnews_bottom").fadeIn(1000);					
                time_sc=2;
            }
        }else{
            $("#fixed_menu").removeClass("fixed_topmenu");
            $("#hotnews_bottom").fadeOut(1000);                
            time_sc=1;
        } 
    });

});


   
