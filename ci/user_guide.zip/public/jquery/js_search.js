function hak_search(e,t,n){
	var r;
	for(var i=0;i<document.forms["search_form"].op_search.length;i++){
		if(document.forms["search_form"].op_search[i].checked){
			r=document.forms["search_form"].op_search[i].value
			}
		}
		if(r=="news"){
			if(document.forms["search_form"].txt_search.value==""){
				alert("សូមបញ្ចូលពាក្សគន្លិះដើម្បីស្វែងរក")
			}else{
				document.forms["search_form"].action="search.php?s="+document.forms["search_form"].txt_search.value+"&lg="+e;document.forms["search_form"].submit()
			}
		}else{
			if(document.forms["search_form"].txt_search.value==""){
				alert("សូមបញ្ចូលពាក្សគន្លិះដើម្បីស្វែងរក")
			}else{
				document.forms["search_form"].action="search.php?s="+document.forms["search_form"].txt_search.value+"&lg="+e;document.forms["search_form"].submit()
			}
		}
	}