function correctPNG(){
	var e=navigator.appVersion.split("MSIE");
	if(parseFloat(e[1])>=5.5&&document.body.filters)
		for(var t=0;t<document.images.length;t++)
		{
			var n=document.images[t],o=n.src.toUpperCase();
			if("PNG"==o.substring(o.length-3,o.length))
			{
				var r=n.id?"id='"+n.id+"' ":"",
					a=n.className?"class='"+n.className+"' ":"",
					i=n.title?"title='"+n.title+"' ":"title='"+n.alt+"' ",
					c="display:inline-block;"+n.style.cssText;"left"==n.align&&(c="float:left;"+c),
					"right"==n.align&&(c="float:right;"+c),n.parentElement.href&&(c="cursor:hand;"+c);
				var s="<span "+r+a+i+' style="width:'+n.width+"px; height:"+n.height+"px;"+c+";filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+n.src+"', sizingMethod='crop');\"></span>";
					n.outerHTML=s,t-=1
				}
		}
}

function getBrowserWindowSize(){
	var e=0,t=0;return"number"==typeof window.innerWidth?(e=window.innerWidth,t=window.innerHeight):document.documentElement
		&& (document.documentElement.clientWidth
		|| document.documentElement.clientHeight)?(e=document.documentElement.clientWidth,
		t = document.documentElement.clientHeight):document.body
		&& (document.body.clientWidth||document.body.clientHeight)
		&& (e=document.body.clientWidth,t=document.body.clientHeight),
		
		{
			width:e,
			height:t
		}
}

function GetXmlHttpObject(){
	return window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null
}
function loadXMLText(e){
	return window.DOMParser?(parser=new DOMParser,xmlDoc=parser.parseFromString(e,"text/xml")):(xmlDoc=new ActiveXObject("Microsoft.XMLDOM"),xmlDoc.async="false",xmlDoc.loadXML(e)),xmlDoc
}
function loadXMLFile(e){
	return window.XMLHttpRequest?xmlhttp=new XMLHttpRequest:xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"),xmlhttp.open("GET.html",e,!1),xmlhttp.send(),xmlDoc=xmlhttp.responseXML,xmlDoc}function getquerystring(e)
{
function t(e,t){
	n+=(n.length>0?"&":"")+escape(e).replace(/\+/g,"%2B")+"="+escape(t||"").replace(/\+/g,"%2B")
	}
	for(var n="",o=document.forms[e].elements,r=0;r<o.length;r++){
		var a=o[r],i=a.type.toUpperCase(),c=a.name;if(c)if("TEXT"==i||"TEXTAREA"==i||"PASSWORD"==i||"BUTTON"==i||"RESET"==i||"SUBMIT"==i||"FILE"==i||"IMAGE"==i||"HIDDEN"==i)t(c,a.value);else if("CHECKBOX"==i&&a.checked)t(c,a.value?a.value:"On");else if("RADIO"==i&&a.checked)t(c,a.value);else if(-1!=i.indexOf("SELECT"))for(var s=0;s<a.options.length;s++){
		var l=a.options[s];l.selected&&t(c,l.value?l.value:l.text)
		}
	}
	return n
}
function msieversion(){
	var e=window.navigator.userAgent,t=e.indexOf("MSIE ");return t>0?parseInt(e.substring(t+5,e.indexOf(".",t))):0
}
function keyEnter(e){
		return 13==(window.event?window.event.keyCode:e.which)
	}
function submitByEnter(e,t,n){
	1==keyEnter(n)&&submitForm(e,t)
}
function submitForm(e,t){
	document.forms[e].action=t,document.forms[e].submit()}function enableDisable(e,t){
		for(i=0;i<t.length;i++)document.getElementById(t[i]).style.display="none";document.getElementById(e).style.display=""
	}
function visibleElement(e,t,n){
	for(i=0;i<t.length;i++)document.forms[e].elements[t[i]].disabled=n
}
function getList(e,t,n,o,r,a,i,c,s,l,d,u){if(null!=e){
	var m="get_list0e68.html?cond="+t+"&table="+a+"&fieldid="+i+"&fieldshow="+c+"&combo="+o+"&select="+r+"&cb_style="+s+"&cb_class="+l+"&dvalue="+d+"&dselect="+u;e.open("get-2.html",m,!0),e.onreadystatechange=function(){
		4==e.readyState&&(document.getElementById(n).innerHTML=e.responseText)
	},e.send(null)}else alert("Your browser does not support XMLHTTP!")
}
function assignValue(e,t,n){
	document.forms[e].elements[t].value=n}function intOnly(e,t){
		var n,o;
		if(window.event)n=window.event.keyCode;
		else{
			if(!t)return!0;
			n=t.which
		}
		return o=String.fromCharCode(n),null==n||0==n||8==n||9==n||13==n||27==n||"0123456789".indexOf(o)>-1
	}
function numOnly(e,t){
		var n,o;if(window.event)n=window.event.keyCode;else{
			if(!t)return!0;
			n=t.which
		}
		return o=String.fromCharCode(n),null==n||0==n||8==n||9==n||13==n||27==n||"0123456789.".indexOf(o)>-1
	}
function removeFile(e,t,n,o,r,a,i,c){
		if(null!=e){
			var s="remove_file0746.html?path="+n+"&filename="+o+"&table="+r+"&field_name="+a+"&field_condition="+i+"&value_condition="+c;
			e.open("get-2.html",s,!0),e.onreadystatechange=function(){
		4==e.readyState&&(document.getElementById(t).innerHTML=e.responseText)},e.send(null)
	}else alert("Your browser does not support XMLHTTP!")}function selectChk(e,t){
		for(var n=e.form.elements,o=0;o<n.length;o++)n[o].name&&n[o].name==t&&(n[o].checked=e.checked)
	}
function edit_pro(e,t,n,o,r){
	eles=document.forms[e].elements;
	for(var a=0;a<eles.length;a++)
	if(eles[a].name&&eles[a].name==t){
		if(1==eles[a].checked)return void submitForm(e,n+"&"+r+"="+eles[a].value);nocheck=!0
	}
	1==nocheck&&alert("Please select "+o+" from the list to edit")
}
function delete_pro(e,t,n,o){
	eles=document.forms[e].elements;
	for(var r=0;r<eles.length;r++)
		if(eles[r].name&&eles[r].name==t)
		{
			if(1==eles[r].checked)return confirm("Are you sure?")?void submitForm(e,n):void 0;nocheck=!0
		}
		1==nocheck&&alert("Please select "+o+" from the list to delete")
	}
function duplicate_pro(e,t,n,o){
	eles=document.forms[e].elements;
	for(var r=0;r<eles.length;r++)
	if(eles[r].name&&eles[r].name==t){
			if(1==eles[r].checked)return void submitForm(e,n);nocheck=!0
		}
		1==nocheck&&alert("Please select "+o+" from the list to duplicate")
	}
function restore_pro(e,t,n,o){
		eles=document.forms[e].elements;
		for(var r=0;r<eles.length;r++)
			if(eles[r].name&&eles[r].name==t){
			if(1==eles[r].checked)return void submitForm(e,n);nocheck=!0
		}
		1==nocheck&&alert("Please select "+o+" from the list to restore")
	}
function empty_pro(e,t,n,o){
		eles=document.forms[e].elements;
		for(var r=0;r<eles.length;r++)
			if(eles[r].name&&eles[r].name==t){
				if(1==eles[r].checked)return confirm("Are you sure?")?void submitForm(e,n):void 0;nocheck=!0
			}
			1==nocheck&&alert("Please select "+o+" from the list to empty")
		}
		function setPerpage(e,t,n,o){
		"all"==n&&(n=o),document.location.href=e+"&perpage="+n+"&paginate="+Math.ceil(t/n)
	}
	function checkArrayValue(e){
		var t=!1;
		for(i=0;i<e.length;i++)if(""!=e[i]){
		t=!0;break
	}
	return t
}
	
function submitSerach(e,t){
	1==checkArrayValue(t)?document.forms[e].submit():alert("Please enter a keyword for searching")
}
function pro_search(e,t,n){
	""!=n?location.href=e+"&fsearch="+t+"&vsearch="+n:alert("Please enter a keyword for searching")
}
function searchContent_sm(e,t,n){
	""==document.asearch_sm.txt_asearch.value||document.asearch_sm.txt_asearch.value.toLowerCase()==t?alert(n):(document.asearch_sm.action="search.php?s="+document.asearch_sm.txt_asearch.value,document.asearch_sm.submit())
}
function searchContent(e,t,n){
	""==document.asearch.txt_asearch.value||document.asearch.txt_asearch.value.toLowerCase()==t?alert(n):(document.asearch.action="search.php?s="+document.asearch.txt_asearch.value,document.asearch.submit())
}
function resetUserPassword(e,t,n){
	if(null!=e){
		e.onreadystatechange=function(){
			4==e.readyState&&(document.getElementById(t).innerHTML=e.responseText,e.close())
		},e.open("POST.html","user_reset_pwd_ajax.html",!0),e.setRequestHeader("Content-type","application/x-www-form-urlencoded"),e.send("userid="+n)
	}else 
	alert("Your browser does not support XMLHTTP!")
}
function memberUserPassword(e,t,n){
		if(null!=e){
			e.onreadystatechange=function(){
				4==e.readyState&&(document.getElementById(t).innerHTML=e.responseText,e.close())
			},e.open("POST.html","member_reset_pwd_ajax.html",!0),e.setRequestHeader("Content-type","application/x-www-form-urlencoded"),e.send("member_id="+n)
		}else 
		alert("Your browser does not support XMLHTTP!")
	}
function setCookie(e,t,n){
		var o=new Date;o.setDate(o.getDate()+n);
		var r=escape(t)+(null==n?"":"; expires="+o.toUTCString());
		document.cookie=e+"="+r}function getCookie(e){
		var t,n,o,r=document.cookie.split(";");
		for(t=0;t<r.length;t++)
			if(n=r[t].substr(0,r[t].indexOf("=")),o=r[t].substr(r[t].indexOf("=")+1),(n=n.replace(/^\s+|\s+$/g,""))==e)return unescape(o)
		}
function formSubmit(e,t){
		document.forms[e].action=t,document.forms[e].submit()
	}
function changeSelectItem(e,t,n,o,r,a,c,s,l,d){
	null!=e?(e.open("POST.html",t,!0),e.setRequestHeader("Content-type","application/x-www-form-urlencoded"),e.onreadystatechange=function(){
			if(4==e.readyState){
			txt=e.responseText,xmlDoc=loadXMLText(txt);
			var t=xmlDoc.getElementsByTagName("option");
			if(document.getElementById(n).options.length=0,""!=l||null!=l){
		a=document.createElement("option");document.getElementById(n).options.add(a),a.value=l,a.text=d}
		if(0==t.length)document.getElementById(n).disabled=!0;else for(i=0;i<t.length;i++){
		var o=t[i].getElementsByTagName("value")[0].childNodes[0].nodeValue,r=t[i].getElementsByTagName("text")[0].childNodes[0].nodeValue,a=document.createElement("option");
		document.getElementById(n).options.add(a),a.value=o,a.text=r,(s+"").toLowerCase()==(o+"").toLowerCase()&&(a.selected=!0),document.getElementById(n).disabled=!1
			}
		}
	},e.send("cond="+o+"&table="+r+"&fieldvalue="+a+"&fieldtext="+c)):alert("Your browser does not support XMLHTTP!")
}
function jwplayer_view(e,t,n,o,r){
		jwplayer(n).setup({flashplayer:"jwplayer/player.swf",id:n,dock:"true",width:e,height:t,autostart:o,file:"<?php echo $current_play; ?>",repeat:"list",image:"<?php echo $screenshot; ?>",repeat:"list"})}function ajax(e,t,n,o){
		var r=GetXmlHttpObject();
		if(null!=r){
			var a=t+".php?"+e;
			r.open("get-2.html",a,!0),r.onreadystatechange=function(){
		4==r.readyState?""!==n?document.getElementById(n).innerHTML=r.responseText:document.getElementById("tmp_").innerHTML=r.responseText:""!=o&&(document.getElementById(n).innerHTML=o)},r.send(null)
	}else 
	alert("Your browser does not support XMLHTTP!")
}
function visitor_search(e){
		var t=document.frm_search;fdate=t.date_from.value,tdate=t.date_to.value,month=t.cmb_months.value;var n="";
		""==fdate&&""==tdate?n="0":""!=fdate&&""!=tdate?n=fdate+"@"+tdate:""!=fdate&&""==tdate?n=fdate:""!=tdate&&""==fdate&&(n=tdate),""!=e&&(vsearch="v_date"==e?n:month),fsearch="visitor$"+e,pro_search_advance("?obj=visitor&act=view",fsearch,vsearch)
	}
function pro_search_advance(e,t,n){
		""!=n&&(location.href=e+"&fsearch="+t+"&vsearch="+n)}function encode64(e){
		var t,n,o,r,a,i="",c="",s="",l=0;
		do{o=(t=e.charCodeAt(l++))>>2,r=(3&t)<<4|(n=e.charCodeAt(l++))>>4,a=(15&n)<<2|(c=e.charCodeAt(l++))>>6,s=63&c,isNaN(n)?a=s=64:isNaN(c)&&(s=64),i=i+keyStr.charAt(o)+keyStr.charAt(r)+keyStr.charAt(a)+keyStr.charAt(s),t=n=c="",o=r=a=s=""}
		while(l<e.length);
		return i
	}
function decode64(e){
		var t,n,o,r,a="",i="",c="",s=0;/[^A-Za-z0-9\+\/\=]/g.exec(e)&&alert("There were invalid base64 characters in the input text.\nValid base64 characters are A-Z, a-z, 0-9, ´+´, ´/´, and ´=´\nExpect errors in decoding."),e=e.replace(/[^A-Za-z0-9\+\/\=]/g,"");
		do {t=keyStr.indexOf(e.charAt(s++))<<2|(o=keyStr.indexOf(e.charAt(s++)))>>4,n=(15&o)<<4|(r=keyStr.indexOf(e.charAt(s++)))>>2,i=(3&r)<<6|(c=keyStr.indexOf(e.charAt(s++))),a+=String.fromCharCode(t),64!=r&&(a+=String.fromCharCode(n)),64!=c&&(a+=String.fromCharCode(i)),t=n=i="",o=r=c=""}
		while(s<e.length);
		return a
	}
var keyStr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";