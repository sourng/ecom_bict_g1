var windowPrototype={
    wdHeight:function(){
        var myHeight;
        if( typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myHeight = window.innerHeight;
        } else if( document.documentElement && (  document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'
            myHeight = document.documentElement.clientHeight;
        } else if( document.body && (  document.body.clientHeight ) ) {
            //IE 4 compatible
            myHeight = document.body.clientHeight;
        }
        return myHeight;
    },
    wdWidth:function(){ 
        var myWidth;
        if( typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myWidth = window.innerWidth;

        } else if( document.documentElement && ( document.documentElement.clientWidth  ) ) {
            //IE 6+ in 'standards compliant mode'
            myWidth = document.documentElement.clientWidth;

        } else if( document.body && ( document.body.clientWidth  ) ) {
            //IE 4 compatible
            myWidth = document.body.clientWidth;
        }
        return myWidth;
    }
}   
function getScrollTop(){
      var ScrollTop = document.body.scrollTop;
       if (ScrollTop == 0)        
         {
             if (window.pageYOffset)
                 ScrollTop = window.pageYOffset;
             else
                 ScrollTop = (document.body.parentElement) ?     document.body.parentElement.scrollTop : 0;
         }
    return ScrollTop;
}
function getElementTop(Elem) {    
    if(document.getElementById) {   
        var elem = document.getElementById(Elem);
    } else if (document.all) {
        var elem = document.all[Elem];        
    }
    if(elem!=null){
        yPos = elem.offsetTop;
        tempEl = elem.offsetParent;
        while (tempEl != null) {
            yPos += tempEl.offsetTop;
            tempEl = tempEl.offsetParent;
        }
        return yPos;
        
    }
    else{
        return 0;
    }    
}
function ads_impression(ads_id){             
    var scrolltop = getScrollTop();
    var advZoneTop = getElementTop('banner_'+ads_id);
    var detectSumScroll = scrolltop+windowPrototype.wdHeight();    
    if(detectSumScroll > advZoneTop){                
        $.post('template/impression.html',{advertise_id:ads_id})                                                                                                                                      
    }else{setTimeout('ads_impression('+ads_id+')',50);}    
} 