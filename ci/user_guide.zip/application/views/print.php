﻿   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from thmeythmey.com/template/print.php?id=63020 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 25 Mar 2018 07:34:39 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(){}function o(e,t,n){return function(){return i(e,[f.now()].concat(u(arguments)),t?null:this,n),t?void 0:this}}var i=e("handle"),a=e(2),u=e(3),c=e("ee").get("tracer"),f=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,t){s[t]=o(d+t,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,o="function"==typeof t;return i(l+"tracer",[f.now(),e,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return t.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],n),e}finally{c.emit("fn-end",[f.now()],n)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=o(l+t)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,f.now()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(o<0?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],4:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?c(e,u,i):i()}function n(n,r,o,i){if(!d.aborted||i){e&&e(n,r,o);for(var a=t(o),u=m(n),c=u.length,f=0;f<c;f++)u[f].apply(a,r);var p=s[y[n]];return p&&p.push([b,n,r,a]),a}}function l(e,t){v[e]=m(e).concat(t)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(n)}function g(e,t){f(e,function(e,n){t=t||"feature",y[n]=t,t in s||(s[t]=[])})}var v={},y={},b={on:l,emit:n,get:w,listeners:m,context:t,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",c=e("gos"),f=e(2),s={},p={},d=t.exports=o();d.backlog=s},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=h.info=NREUM.info,t=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return s.abort();f(y,function(t,n){e[t]||(e[t]=n)}),c("mark",["onload",a()+h.offset],null,"api");var n=d.createElement("script");n.src="https://"+e.agent,t.parentNode.insertBefore(n,t)}}function o(){"complete"===d.readyState&&i()}function i(){c("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),c=e("handle"),f=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=t.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>

    <?php include_once 'include/head.php'; ?>

</head>
 <?php foreach($article as $row){ ?>
<body style="background:#ffffff;">
    <div style="float:left;border:0px solid red;margin:0;padding:0;width:100%">
        <div style="width:680px;float:none; margin:0 auto; border:0px solid blue;"> 
            <div style="width:100px; height:100px;margin:0 auto">
                <img src="<?php echo base_url() ;?>public/icon.san.com/logo.png" width='111'/>
            </div> 
            <br>      
            <div class='detail_dp_title_ctn'>
                <span class='kh size30_kh dark lineheight36_kh'>
                   <?php echo $row['art_title'];?>
                </span>
                <div class='left w100'>
                    <span class='title_kh gray lineheight40_kh size12_kh'>ដោយ: 
                        <a href='print5e55.html?page=author&amp;id=45' class='m1 size15_kh italic'>
                             <?php echo $row['user_kh_fname'].' '.$row['user_kh_lname'];?>
                        </a> 
                    </span> &nbsp; &nbsp;
                    <span class='title_kh gray lineheight30_kh size12_kh'>
                        <i class='icon-calendar icon size12_kh'></i>  <?php echo $row['art_date'];?> , 
                        <i class='icon-time icon size12_kh'></i> <?php echo $row['art_date'];?> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <i class='icon-eye-open size12_kh'></i> 
                        <?php  foreach ($count_views as $views) {
                              echo $views['views'];
                            } ?> 
                    </span>
                </div>
            </div>
            <img src='<?php echo base_url();?>public/image.san.com/<?php echo $row['art_feature_img'];?>' width='100%' style='margin-top:15px;margin-bottom:15px;margin-left:auto;margin-left:right'/>
                    <div class='title_image'>
                        <span class='title_kh size14_kh italic dark lineheight30_kh'> 
                            <?php echo $row['art_feature_img_dec'];?>
                        </span>
                    </div>
                    <br/>
            <span class='left kh size17_kh dark'>
                 <?php echo add_path($row['art_detail']);?>
            </span>

            <div style='float:left;padding-top:2px;'> 
                <div class='addthis_toolbox addthis_default_style addthis_32x32_style'>
                    <a class='addthis_button_facebook'></a>
                    <a class='addthis_button_twitter'></a>
                    <a class='addthis_button_linkedin'></a>
                    <a class='addthis_button_myspace'></a>
                    <a class='addthis_button_tumblr'></a>
                    <a class='addthis_button_blogger'></a>
                    <a class='addthis_button_pinterest_share'></a>
                    <a class='addthis_button_google_plusone_share'></a>
                    <a class='addthis_button_google'></a>
                    <a class='addthis_button_email'></a>
                    <a class='addthis_button_compact'></a>
                    <a class='addthis_counter addthis_bubble_style'></a>
                </div>
                </div>
                <div class='panel-danger left kh lineheight22_kh'> 
                    <i class='icon-legal'></i> រក្សាសិទ្ធិដោយ san.com
                </div>            
                 <br style="clear: both;" />               
        </div> 
    </div>
    <script type="text/javascript">window.print();</script>
    <script type="text/javascript">
    window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"3407f15dfb","applicationID":"21144547","transactionName":"blFWYUNYDBFTWhIPDFcbYUdYFhYHX0kKBxdcG0RHWFcWTEJRFg==","queueTime":0,"applicationTime":1,"atts":"QhZVFwtCHx8=","errorBeacon":"bam.nr-data.net","agent":""}
    </script>
     <?php } ?>
</body>
</html>