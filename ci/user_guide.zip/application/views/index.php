﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
     <?php include_once 'include/head.php';?>      
</head>
<body>
    <!--popUp--> 
            <script type="text/javascript">
                $(document).ready(function(){                    
                   // $('#popup_thmeythmey').fadeIn(900).load('include/ad_popup.php?v=2');
                   $('#active_menu').addClass('current');
                   });	          
            </script> 
    <!--end popUp-->  

    <img src="<?php echo base_url();?>public/icon.san.com/logo.png" style='display:none' />          
    <div id="popup_thmeythmey" style="position: fixed;width: 100%;z-index: 99999999 !important;"></div>  

                                     
     <?php include_once 'include/menu.php';?> 
        <div class="inner"><!-- INNER CLASS FOR MAKE AUTO CENTER -->                         
            <div class="container">                                                              
                <?php include_once 'include/ad_banner_top_left.php';?>               
                <div class="containt_body left"><!-- Page Container -->      
                    <?php include_once 'include/ad_banner_top.php';?>                                    
                    <div class="container_body"><!--- BODY CONTAINER -->                            
                       <div class="whole_body_ctn dspblock left"><!---whole body-->                                        	        
    						
       			 			<?php include_once 'include/news_feature.php';?>

						    <div class="dspblock whol_lbody_ctn left">                      
						        <div class="dspblock lpanel_inner"><!--lpanel--> 
						            <div class="left w100">                                   	                   	
						                ﻿<div style="float: left;width:100%;min-height:500px;"> 
						                	 <?php 
                                                echo detectDevice();                                                
                                                 $url_array =  explode('san.com/', $_SERVER['REQUEST_URI']) ;
                                                $url = end($url_array); 
                                                echo '<br>'.$url;


                                            ?> 
												
						                    <?php include_once 'include/v_list_all_pages.php';?>
						                </div>               
						            </div>            
						        </div><!--end lpanel-->                
						    </div><!--endlboby--> 

						    <div class="dspblock whole_rbody_ctn right" id="rpanel"><!--rbody-->        
						        <?php include_once 'include/ad_banner_right.php';?>
						        <?php include_once 'include/news_popular.php';?>

								<div class="ad right" style="width:260px;height:100px;overflow: hidden;position: relative;z-index:0;test-align:right">
								    
								    <script type="text/javascript" src="<?php echo base_url();?>public/digi.com.kh/banners/thmeythmey/285-100.js"></script>     
								      
								</div>
								<div class="border_block_ad left w100">
								    <div class="right" style="padding:5px 0;">
								        <div class="fb-like-box" data-href="https://www.facebook.com/ThmeyThmey" data-width="280" data-height="520" data-show-faces="true" data-stream="true" data-show-border="false" data-header="false"></div>
								    </div>    
								</div>                            
						    </div><!--end rbody-->
    
						</div>                                      
					</div><!-- End BODY Container -->                                                                                                               
				</div><!-- End Page Container -->   
	                                    
               
                <div style="clear:both"></div>
            </div>   <!--End class container-->               
        </div>	 <!--End class="inner"-->

    <?php include_once 'include/ad_banner_top_right.php';?>                                     
	<?php include_once 'include/ad_banner_bottom.php';?> 
    <?php include_once 'include/footer.php';?>
</body>
</html>
