 <!--Nationel news-->
    <div class="werrapper_block_news w100 left">   
        <div class="bg_title_center left">                              
            <div class="icon_white">
                <span class="menu lineheight36_kh blue size16_kh">
                    ព័ត៌មានជាតិ              
                </span> 
            </div> 
                                         
        </div>                                                                                                         
        <div class="new_block_body_big left wow fadeInDown">          
            <div class="new_block_body_in w100 left"> 

                  <?php 
                       $i=1;
                      foreach($national as $row){ 
                        if ($i==1) {
                          ?>

                <div class='news_icon_first left '>
                    <div class='img_item_news_big left lazy'>
                        <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='left'>
                            <img class='lazy' data-src="<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=196&h=130&q=100&s";?>" alt=' <?php echo ($row['art_title']);?>' title=''>
                        </a>
                    </div>
                    <div class='right title_item_news_big'>
                        <span class='left kh lineheight22_kh size16_kh white'>
                            <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='sign_articles m3 effect_over'>
                               <?php echo short_title($row['art_title'],220);?>
                            </a> 
                            <div class='item_of_article_ w100 title_kh lineheight22_kh'> 
                                <span class='sign_article title_kh left size12_kh '>សង្រ្កាន្តឆ្នាំថ្មី</span>  
                                <span class='sign_article title_kh left size12_kh '> សៀមរាប </span> 
                                <span class='size12_kh  comment_icon'>
                                    <font class='comment_icon'><i class='icon-calendar icon size11_kh'></i> 
                                        <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                    </font>
                                </span>
                            </div>
                        </span>
                      </div>
                    </div>

                

                          <?php
                        }else{
                            ?>
                             <div class='news_icon_first left margin_left'>
                    <div class='img_item_news_big left lazy' style="width:100%">
                        <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='left'>
                            <img class='lazy' data-src='<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=196&h=130&q=100&s";?>' alt='<?php echo ($row['art_title']);?>' title=''>
                        </a>
                    </div>
                    <div class='right title_item_news_big'>
                        <span class='left kh lineheight22_kh size16_kh white'>
                            <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='sign_articles m3 effect_over'> 
                                <?php echo short_title($row['art_title'],220);?>
                            </a> 
                            <div class='item_of_article_ w100 title_kh lineheight22_kh'> 
                                <span class='sign_article title_kh left size12_kh '>សង្រ្កាន្តឆ្នាំថ្មី</span>  
                                <span class='sign_article title_kh left size12_kh '> សៀមរាប </span> 
                                <span class='size12_kh  comment_icon'>
                                    <font class='comment_icon'><i class='icon-calendar icon size11_kh'></i> 
                                        <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                    </font>
                                </span>
                            </div>
                        </span>
                      </div>
                    </div>   
                            <?php

                        }
                        
                        if ($i==3) {
                           $i=1;
                        }else{
                            $i=$i+1;
                        }
                      }
                    ?>
                                                                                                                                                       
                
            </div>    
            <div class="see_more effect_over right">
                <span class="search_page_readmore_link title_kh lineheight32_kh size12_kh">                    
                    <a href=" <?php echo site_url().'page/'.$row['cat_id']; ?>">
                        <?php echo $row['cat_kh_name'].'បន្ថែម'; ?>              
                     </a>
                </span>
            </div>                                                                                                                    
        </div>
    </div>
    <!--End Nataional news-->
                  
    <div class="ad left" style="width:690px;height:100px;overflow: hidden;position: relative;z-index:0;">        
        <script type="text/javascript" src="<?php echo base_url();?>public/digi.com.kh/banners/thmeythmey/664-100.js"></script>
    </div> 

     <!--Enternationel news-->
    <div class="werrapper_block_news w100 left">   
        <div class="bg_title_center left">                              
            <div class="icon_white">
                <span class="menu lineheight36_kh blue size16_kh">
                    ព័ត៌មានជាតិ              
                </span> 
            </div> 
                                         
        </div>                                                                                                         
        <div class="new_block_body_big left wow fadeInDown">          
            <div class="new_block_body_in w100 left"> 

                  <?php 
                       $i=1;
                      foreach($enternational as $row){ 
                        if ($i==1) {
                          ?>

                <div class='news_icon_first left '>
                    <div class='img_item_news_big left lazy'>
                        <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='left'>
                            <img class='lazy' data-src="<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=196&h=130&q=100&s";?>" alt=' <?php echo ($row['art_title']);?>' title=''>
                        </a>
                    </div>
                    <div class='right title_item_news_big'>
                        <span class='left kh lineheight22_kh size16_kh white'>
                            <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='sign_articles m3 effect_over'>
                               <?php echo short_title($row['art_title'],220);?>
                            </a> 
                            <div class='item_of_article_ w100 title_kh lineheight22_kh'> 
                                <span class='sign_article title_kh left size12_kh '>សង្រ្កាន្តឆ្នាំថ្មី</span>  
                                <span class='sign_article title_kh left size12_kh '> សៀមរាប </span> 
                                <span class='size12_kh  comment_icon'>
                                    <font class='comment_icon'><i class='icon-calendar icon size11_kh'></i> 
                                        <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                    </font>
                                </span>
                            </div>
                        </span>
                      </div>
                    </div>

                

                          <?php
                        }else{
                            ?>
                             <div class='news_icon_first left margin_left'>
                    <div class='img_item_news_big left lazy' style="width:100%">
                        <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='left'>
                            <img class='lazy' data-src='<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=196&h=130&q=100&s";?>' alt='<?php echo ($row['art_title']);?>' title=''>
                        </a>
                    </div>
                    <div class='right title_item_news_big'>
                        <span class='left kh lineheight22_kh size16_kh white'>
                            <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='sign_articles m3 effect_over'> 
                                <?php echo short_title($row['art_title'],220);?>
                            </a> 
                            <div class='item_of_article_ w100 title_kh lineheight22_kh'> 
                                <span class='sign_article title_kh left size12_kh '>សង្រ្កាន្តឆ្នាំថ្មី</span>  
                                <span class='sign_article title_kh left size12_kh '> សៀមរាប </span> 
                                <span class='size12_kh  comment_icon'>
                                    <font class='comment_icon'><i class='icon-calendar icon size11_kh'></i> 
                                        <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                    </font>
                                </span>
                            </div>
                        </span>
                      </div>
                    </div>   
                            <?php

                        }
                        
                        if ($i==3) {
                           $i=1;
                        }else{
                            $i=$i+1;
                        }
                      }
                    ?>
                                                                                                                                                       
                
            </div>    
            <div class="see_more effect_over right">
                <span class="search_page_readmore_link title_kh lineheight32_kh size12_kh">                    
                    <a href=" <?php echo site_url().'page/'.$row['cat_id']; ?>">
                         <?php echo $row['cat_kh_name'].'បន្ថែម'; ?>               
                     </a>
                </span>
            </div>                                                                                                                    
        </div>
    </div>
    <!--End Enternataional news-->
<!--Enternationel news-->
    <div class="werrapper_block_news w100 left">   
        <div class="bg_title_center left">                              
            <div class="icon_white">
                <span class="menu lineheight36_kh blue size16_kh">
                    ព័ត៌មានជាតិ              
                </span> 
            </div> 
                                         
        </div>                                                                                                         
        <div class="new_block_body_big left wow fadeInDown">          
            <div class="new_block_body_in w100 left"> 

                  <?php 
                       $i=1;
                      foreach($sport as $row){ 
                        if ($i==1) {
                          ?>

                <div class='news_icon_first left '>
                    <div class='img_item_news_big left lazy'>
                        <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='left'>
                            <img class='lazy' data-src="<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=196&h=130&q=100&s";?>" alt=' <?php echo ($row['art_title']);?>' title=''>
                        </a>
                    </div>
                    <div class='right title_item_news_big'>
                        <span class='left kh lineheight22_kh size16_kh white'>
                            <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='sign_articles m3 effect_over'>
                               <?php echo short_title($row['art_title'],220);?>
                            </a> 
                            <div class='item_of_article_ w100 title_kh lineheight22_kh'> 
                                <span class='sign_article title_kh left size12_kh '>សង្រ្កាន្តឆ្នាំថ្មី</span>  
                                <span class='sign_article title_kh left size12_kh '> សៀមរាប </span> 
                                <span class='size12_kh  comment_icon'>
                                    <font class='comment_icon'><i class='icon-calendar icon size11_kh'></i> 
                                        <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                    </font>
                                </span>
                            </div>
                        </span>
                      </div>
                    </div>

                

                          <?php
                        }else{
                            ?>
                             <div class='news_icon_first left margin_left'>
                    <div class='img_item_news_big left lazy' style="width:100%">
                        <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='left'>
                            <img class='lazy' data-src='<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=196&h=130&q=100&s";?>' alt='<?php echo ($row['art_title']);?>' title=''>
                        </a>
                    </div>
                    <div class='right title_item_news_big'>
                        <span class='left kh lineheight22_kh size16_kh white'>
                            <a href='<?php echo site_url();?>article/<?php echo $row['art_id']; ?>' class='sign_articles m3 effect_over'> 
                                <?php echo short_title($row['art_title'],220);?>
                            </a> 
                            <div class='item_of_article_ w100 title_kh lineheight22_kh'> 
                                <span class='sign_article title_kh left size12_kh '>សង្រ្កាន្តឆ្នាំថ្មី</span>  
                                <span class='sign_article title_kh left size12_kh '> សៀមរាប </span> 
                                <span class='size12_kh  comment_icon'>
                                    <font class='comment_icon'><i class='icon-calendar icon size11_kh'></i> 
                                        <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                    </font>
                                </span>
                            </div>
                        </span>
                      </div>
                    </div>   
                            <?php

                        }
                        
                        if ($i==3) {
                           $i=1;
                        }else{
                            $i=$i+1;
                        }
                      }
                    ?>
                                                                                                                                                       
                
            </div>    
            <div class="see_more effect_over right">
                <span class="search_page_readmore_link title_kh lineheight32_kh size12_kh">                    
                    <a href=" <?php echo site_url().'page/'.$row['cat_id']; ?>">
                         <?php echo $row['cat_kh_name'].'បន្ថែម'; ?>               
                     </a>
                </span>
            </div>                                                                                                                    
        </div>
    </div>
    <!--End Enternataional news-->
    

