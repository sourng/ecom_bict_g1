<div class="dspblock whol_lbody_ctn left"><!--lbody-->              
        <div class="dspblock lpanel_inner left" id="lpanel"><!--lpanel--> 
            <div class="werrapper_block_news left w100">
                <div class="bg_title_center left">                              
                    <div class="icon_white">
                        <span class="menu lineheight28_kh blue size16_kh">
                            លទ្ធផលស្វែងរក              
                        </span> 
                    </div>                                          
                </div>                                                                                                                                                                                              
                <div class="new_block_body_big left">                                                                                        
                    <div class="title_search_each w100 left title_kh lineheight36_kh size14_kh dark_desc"> 
                        <span class="size14_kh">សរុប: </span> 
                        <b class="red">12345</b> 
                        &nbsp;ចំនួនលទ្ធផលស្វែងរកនៃពាក្ស&nbsp;: <?php echo @$_GET['u'];?>
                        <font style="color:#d60d13"></font>
                    </div>
                    <div class="wow fadeInDown animated similler_article left   animated" style="visibility: visible; animation-name: fadeInDown;">
                        <a href="?page=detail&amp;id=63107" class="m3 left">
                            <div class="left bg_abov_img effect_over">
                            <div class="left title">
                                <span class="title_kh lineheight24_kh size15_kh white">
                                ពីមួយ&#8203;ឆ្នាំទៅ&#8203;មួយឆ្នាំ កម្ពុជា ចំណាយ&#8203;ពី ៤0 ទៅ ៥0&#8203;លាន&#8203;ដុល្លារ ដើម្បី&#8203;ទប់ស្កាត់&#8203;ជំងឺអេដស៍&#8203;
                            </span>
                            <div class="item_of_article w100 left title_kh">
                                <div class="all_sign_article left"></div>
                                <span class="left size11_kh lineheight22_kh comment_icon"> 
                                    <span class="sign_article title_kh left size12_kh "></span> 
                                    <font class="comment_icon">
                                        <i class="icon-calendar icon size12_kh"></i>
                                        <span class="comment_icon"> 17 នាទី </span>
                                    </font>
                                </span>
                            </div>
                        </div>
                    </div>
                </a>
                <div class="left img_tag_article img-responsive">
                    <img class="left lazy" width="" height="200" 
                    alt="ពីមួយ&#8203;ឆ្នាំទៅ&#8203;មួយឆ្នាំ កម្ពុជា ចំណាយ&#8203;ពី ៤0 ទៅ ៥0&#8203;លាន&#8203;ដុល្លារ ដើម្បី&#8203;ទប់ស្កាត់&#8203;ជំងឺអេដស៍&#8203;" title="ពីមួយ&#8203;ឆ្នាំទៅ&#8203;មួយឆ្នាំ កម្ពុជា ចំណាយ&#8203;ពី ៤0 ទៅ ៥0&#8203;លាន&#8203;ដុល្លារ ដើម្បី&#8203;ទប់ស្កាត់&#8203;ជំងឺអេដស៍&#8203;" src="https://image.thmeythmey.com/pictures/2018/03/26/thumb1/263201819101.jpg" style="display: block;">
                </div>
            </div>
                <div class="pagination_ctn left"><!-- pagination -->
                    <div class="sabrosus en size13_en">
                        <span class="disabled">prev</span>
                        <span class="current">1</span>
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=2">2</a>
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=3">3</a>
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=4">4</a>
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=5">5</a>
                        ...
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=415">415</a>
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=416">416</a>
                        <a href="https://thmeythmey.com/?page=search&amp;paginate=2">next</a>
                    </div>                    
                </div><!-- end pagination -->      
                                                                         
                </div>                                                                                                                                                    
            </div>
        </div>                                                                                                                                             
    </div>