 <div class="dspblock whol_lbody_ctn left"><!--lbody-->                    
        <div class="dspblock lpanel_inner left" id="lpanel"><!--lpanel-->             
                        
            <div class="werrapper_block_news left">                       
                <div class="bg_title_center left"><!--title_location-->                             
                    <div class="icon_white">
                        <span class="menu lineheight28_kh blue size18_kh">
                                        
                        </span>
                    </div>          
                                                 
                </div><!--end title_location-->                                                                                                                                                                                                                                              
                <div class="new_block_body_big left">          
                        <div class="new_block_body_in left">
                            <?php 
                               $i=1;                               
                              foreach($page as $row){
                               
                                if ($i==1) {
                                  ?>
                            <div class="wow fadeInDown animated similler_article left animated" style="visibility: visible; animation-name: fadeInDown;">
                                <a href="<?php echo site_url();?>article/<?php echo ($row['art_id']);?>" class="m3 left">
                                    <div class="left bg_abov_img effect_over">
                                        <div class="left title">
                                            <span class="title_kh lineheight24_kh size15_kh white">
                                           <?php echo short_title($row['art_title'],250);?>
                                            </span>
                                        <div class="item_of_article w100 left title_kh">
                                            <div class="all_sign_article left"></div>
                                            <span class="left size11_kh lineheight22_kh comment_icon"> 
                                                <span class="sign_article title_kh left size12_kh "> </span> 
                                                <font class="comment_icon">
                                                    <i class="icon-calendar icon size12_kh"></i>
                                                    <span class="comment_icon"> <?php echo time_ago($row['art_date']);?> </span>
                                                </font>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <div class="left img_tag_article img-responsive">
                                <img class="left lazy" width="" height="" 
                                alt="<?php echo ($row['art_title']);?>" src="<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=308&h=200&q=100&s";?>" style="display: block;">
                            </div>
                        </div>
                         <?php
                        }elseif($i==2){
                            ?>
                        <div class="wow fadeInDown animated similler_article right animated" style="visibility: visible; animation-name: fadeInDown;">
                                <a href="<?php echo site_url();?>article/<?php echo ($row['art_id']);?>" class="m3 left">
                                    <div class="left bg_abov_img effect_over">
                                        <div class="left title">
                                            <span class="title_kh lineheight24_kh size15_kh white">
                                            <?php echo short_title($row['art_title'],250);?>
                                            </span>
                                        <div class="item_of_article w100 left title_kh">
                                            <div class="all_sign_article left"></div>
                                            <span class="left size11_kh lineheight22_kh comment_icon"> 
                                                <span class="sign_article title_kh left size12_kh "> </span> 
                                                <font class="comment_icon">
                                                    <i class="icon-calendar icon size12_kh"></i>
                                                    <span class="comment_icon"><?php echo time_ago($row['art_date']);?> </span>
                                                </font>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <div class="left img_tag_article img-responsive">
                                <img class="left lazy" width="" height="" 
                                alt="<?php echo ($row['art_title']);?>" src="<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=308&h=200&q=100&s";?>" style="display: block;">
                            </div>
                        </div>
                        <?php

                        }else{

                            ?>

                         <div class="right news_icon wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                            <a href="<?php echo site_url();?>article/<?php echo $row['art_id']; ?>" class="left">
                                <div class="left img_short_detail">
                                    <img class="lazy" 
                                    alt="<?php echo ($row['art_title']);?>" src="<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=240&h=170&q=100&s";?>" style="display: inline;">
                                </div>
                                
                            </a>
                            <div class="title_item_news left">
                                <span class="title_kh lineheight26_kh size18_kh dark left">
                                    <a href="<?php echo site_url();?>article/<?php echo $row['art_id']; ?>" class="m3 effect_over">
                                        <?php echo short_title($row['art_title'],250);?>
                                    </a> 
                                </span>
                            </div>
                            <div class="item_of_article left lineheight26_kh en">
                                <div class="all_sign_article size12_kh left"> 
                                    <a href="<?php echo site_url();?>author/<?php echo $row['user_id']; ?>">
                                    <span class="sign_article title_kh left size12_kh "> 
                                        
                                        <?php echo ($row['user_kh_fname'].' '.$row['user_kh_lname']);?> 
                                        
                                    </span>  
                                    </a>
                                    <span class="left size12_kh title_kh comment_icon">
                                        <font class="icon"> <i class="icon-calendar icon size12_kh"></i>
                                            <span class="comment_num">  <?php echo time_ago($row['art_date']);?> </span>
                                        </font>
                                    </span>
                                </div>
                            </div>
                            <div class="short_detail_ctn left visible-slide">
                                <span class="kh size16_kh lineheight22_kh dark_desc">
                                    <?php echo short_title($row['art_detail'],500);?>
                                </span>
                             </div>
                        </div>    
                            <?php
                        }
                        
                      
                            $i=$i+1;
                        
                      }
                    ?>

                          
                    
                                         
                        <!-- pagination -->
                        <div class="pagination_ctn left">
                            <div class="sabrosus en size13_en">
                                <span class="disabled">prev</span>
                                <span class="current">1</span>
                                <a href="indexcdf2.html?page=location&amp;id=9&amp;paginate=2">2</a>
                                <a href="index5622.html?page=location&amp;id=9&amp;paginate=3">3</a>
                                <a href="index8947.html?page=location&amp;id=9&amp;paginate=4">4</a>
                                <a href="index2a98.html?page=location&amp;id=9&amp;paginate=5">5</a>
                                <a href="indexe114.html?page=location&amp;id=9&amp;paginate=6">6</a>
                                <a href="indexcdf2.html?page=location&amp;id=9&amp;paginate=2">next</a>
                            </div>  
                        </div>                                                                                                        
                    </div>                                                                                   
                </div>
            </div>                                                                                   
        </div>
    </div>