
<style>
    #thmeythmey{width:100%;height:100%;z-index:1000;background:#000;position:fixed;left:0;top:0;filter:alpha(opacity=70);opacity:.7}    
    #thmeythmey-ads{z-index:1001;width:100%;height:100%;color:#FFF;position:fixed;left:0%;right:0%;top:10%;bottom:0%;}
    .ads_popup{height:auto;margin: 0 auto;width:700px;position: relative;background:rgba(7, 94, 160, 0.8);border-radius:3px;padding-top:8px;padding-bottom:0px}
    .ads_popup img{height:auto;}        
</style>

<div id='thmeythmey'></div>
<div id='thmeythmey-ads'>
    <div class="ads_popup w100 img-responsive" >
        <div class="lineheight16_en en">
            <div style='width:350px; display:inline-block;float: left;margin:0 0 0px 0px;position: relative;z-index: 2;top:-4px;left:10px'>
                <img style='cursor:pointer;width:20px; height:20px; vertical-align:middle; margin-right:10px;' src='<?php echo base_url();?>public/icon.thmeythemy.com/pause.png' onclick="pause_ads(this)">
                <span id='thmeythmey-progress' style='vertical-align:middle;'><img src="<?php echo base_url();?>public/icon.thmeythemy.com/GsNJNwuI-UM.gif" /></span>
            </div>
        </div>
        <div style='position:absolute; top:5px; right:10px;'>
            <img style='cursor:pointer;' onclick='hide_ads()' src='<?php echo base_url();?>public/icon.thmeythemy.com/btn-close.png' width="20"/>
        </div>
      
                 <center>
                    <a id='banner_386' href='#' onclick="myFunctionClick('386','http://cam-asean-training.com/')"><img id='thmeythmey-image' src='https://a.thmeythmey.com/advertise/386/thmey-thmey-banner.jpg' width='700' height= alt='Cam-Asean-Popup' class='img-responsive'/></a><script type='text/javascript'> impression(386);</script>                
                </center>
        
    </div>  
    <script>
        function hide_ads(){$("#thmeythmey").hide(),$("#thmeythmey-ads").hide()}
        function pause_ads(e){pause?($(e).attr("src","<?php echo base_url();?>public/icon.thmeythemy.com/pause.png"),pause=!1):($(e).attr("src","<?php echo base_url();?>public/icon.thmeythemy.com/play.png"),pause=!0)}
            var counter=6,pause=!1;
            $("#thmeythmey-image").load(function(){var e=setInterval(function(){
                if(!pause){
                    if(1>counter)return clearInterval(e),void hide_ads();counter--,$("#thmeythmey-progress").html("<i class='icon-time size16_en lineheight16_en'></i> "+counter)
                }
            },1e3)}),$("#thmeythmey").click(function(){hide_ads()});
    </script>
    <!-- Takeover :: End -->
</div>