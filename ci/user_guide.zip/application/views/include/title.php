       <div class="w100 left block_bar_top">
        <!--title-->
    <link rel="stylesheet" href="css/tipso.css"/>
<script src="<?php echo base_url();?>public/jquery/tipso.js"></script>
<script> jQuery(document).ready(function(){jQuery('.title-tipso').tipso({useTitle: true});}); </script>
<div class="containt_bar">
    <div style="height:20px;width:17px;" class="right"></div>   
    <div class="icon_top_bar right">        
        <a href="https://www.thmeythmey.com/feeds/" class="app effect_over" target="_blank">
            <div class="size16_kh lineheight22_kh title-tipso" title="Feed ThmeyThmey">
                <i class="icon-rss"></i>
            </div>                              
        </a>     
    </div>
    <div class="icon_top_bar right">        
        <a href="https://www.youtube.com/c/ThmeyThmeyOnlineNews" class="app effect_over" target="_blank">
            <div class="size16_kh lineheight22_kh title-tipso" title="Youtube ThmeyThmey">
                <i class="icon-youtube"></i>
            </div>                              
        </a>     
    </div>
    <div class="icon_top_bar right">    
        <a href="https://www.instagram.com/ThmeyThmey/" class="app effect_over" target="_blank">
            <div class="size16_kh lineheight22_kh title-tipso" title="Instagram ThmeyThmey">
                <i class="icon-instagram"></i>
            </div>                              
        </a>     
    </div>
    <div class="icon_top_bar right">    
        <a href="https://twitter.com/thmeythmey" class="app effect_over" target="_blank">
            <div class="size16_kh lineheight22_kh title-tipso" title="Twitter ThmeyThmey">
                <i class="icon-twitter"></i>
            </div>                              
        </a>     
    </div>
    <div class="icon_top_bar right">    
        <a href="https://www.facebook.com/thmeythmeyvideonews/" class="app effect_over" target="_blank">
            <div class="size16_kh lineheight22_kh title-tipso" title="Facebook ThmeyThmey">
                <i class="icon-facebook"></i>
            </div>                              
        </a>     
    </div>        
    <div class="icon_top_bar right">        
        <a href="https://vdo.thmeythmey.com/" class="app effect_over" target="_blank">
            <div class="size19_kh lineheight22_kh title-tipso" title="VDO ThmeyThmey">
                <i class="icon-globe"></i>
            </div>                              
        </a>     
    </div>           
</div>                                  
</div><!--end title-->
