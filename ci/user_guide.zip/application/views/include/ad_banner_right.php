<div class="border_block_ad left w100">
    <div class="ad right">
                 
            <script type="text/javascript" language="javascript">
                $(window).load(function(){$(function(){$("#foo2_Book").carouFredSel({width:"285",height:"auto",prev:"#prev2_ad",next:"#next2_ad",auto:!0,direction:"right",scroll:{item:1,duration:1e3,pauseOnHover:!0}})})});             
            </script>
            <style type="text/css" media="all">
                .list_carousel_Book{width:285px;height:px;border:0 solid #000;margin:0!important}.list_carousel_Book ul{margin:0;padding:0;list-style:none;display:block;border:0 solid #ff0}.list_carousel_Book li{color:#AC0F18;text-align:center;border:0;width:285px;height:px;padding:0;padding-top:0;padding-left:0;margin:0;display:block;float:left;cursor: pointer;border:0 solid #ff0;position:relative;z-index:0}.list_carousel_Book.responsive{width:auto;margin-left:0}.caroufredsel_wrapper_Book{border:0 solid green}           
            </style>
            <!--promot dfdfdf-->                                                                                   
        <!--     <div id='banner_324' class='ad_banner  right ' onclick="myFunctionClick('324','http://angkorbeauty.net/growth-height-p29')">
            	<img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/324/grow_hieght_pro_280x280.gif' width='280' height=400 alt='Grow Height Pro'  class='img-responsive'/>
            	<script type='text/javascript'> impression(324);</script>
            </div>
            <div id='banner_270' class='ad_banner  right ' onclick="myFunctionClick('270','http://booloombooloom.com/')">
            	<img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/270/thmeythmey-035boloom.gif' width='285' height=285 alt='Booloom Booloom - Browser PC'  class='img-responsive'/><script type='text/javascript'> impression(270);</script>
            </div> -->
            <div class='right ad_banner ' style='width:285px;height:px;position:relative;'>
            	<div class='promotion'>
            		<div class='list_carousel_Book' style='position:relative; top:0px; left:0px;'>
	            		<div class='caroufredsel_wrapper_Book' style='height:px; width:285px;overflow: hidden;'>
	            			<ul id='foo2_Book'>
	            				<li id='banner_288' onclick="myFunctionClick('288','indexb9f5.html?page=detail&amp;id=61054')">
	            					<img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/288/cbd-success.jpg' width=285 height= alt='Book 1' class='img-responsive'>
	            					<script type='text/javascript'> impression('288'); </script>
	            				</li>
	            			</ul>
	            		</div>
	            	</div>
	            </div>
	        </div>          
    </div><!--end ad-->
</div>﻿<div class="ad right">
              
</div><!--end ad--> 
<!-- <div class="ad_banner right ">
     <iframe class="right" id="ttn_ads_vdo" width="260" height="240" src="https://www.youtube.com/embed/azuvCga_xis?rel=0&amp;autoplay=1&amp;loop=2&amp;enablejsapi=1&#10;" frameborder="0" allowfullscreen=""></iframe>
     <script src="https://www.youtube.com/iframe_api"></script>
     <script>function onYouTubeIframeAPIReady(){player=new YT.Player("ttn_ads_vdo",{events:{onReady:onPlayerReady}})}function onPlayerReady(){player.playVideo(),player.mute()}var player;</script>
</div> -->
<div class="ad right">
    <div id='banner_366' class='ad_banner  right ' onclick="myFunctionClick('366','https://www.facebook.com/PanhaChietUniversity/?ref=br_tf')"><img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/366/p7ewqdda.gif' width='280' height= alt='PUC'  class='img-responsive'/><script type='text/javascript'> impression(366);</script></div>          
</div><!--end ad--> 
