<link rel="stylesheet" href="<?php echo base_url();?>public/css/author.css?v=0.4" />
<div class="block-info-profile left">

     <?php   foreach($users as $row){ ?>        
        <div class='info-profile left'>
            <div class='left author-name w100'>
                <span class='title_kh lineheight40_kh blue size36_kh'><?php echo $row['user_kh_fname'].' '.$row['user_kh_lname']?></span>
            </div>
            <div class='left author-position w100'>
                <span class='title_kh lineheight36_kh lightblue size17_kh'>ស្ថាបនិក និងអគ្គនាយក</span>
            </div>
            <div class='left author-icon w100 white size15_kh lineheight20_kh'>
                <span class='left icon-socail-f'><i class='icon-facebook'></i></span>
                <span class='title_kh lineheight24_kh lightgray size15_kh'>
                    <a href='https://www.facebook.com/<?php echo $row['user_fb'];?>' class='m5' target='_blank'><?php echo $row['user_fb'];?></a>
                </span>
            </div>
            <div class='left author-icon w100 white size15_kh lineheight20_kh'>
                <span class='left icon-socail-t'><i class='icon-twitter'></i></span>
                <span class='title_kh lineheight24_kh lightgray size15_kh'>
                    <a href='https://www.twitter.com/<?php echo $row['user_tw'];?>' class='m5' target='_blank'><?php echo $row['user_tw'];?></a>
                </span>
            </div>
            <div class='left author-icon w100 white size15_kh lineheight20_kh'>
                <span class='left icon-socail-e'><i class='icon-envelope'></i></span>
                <span class='title_kh lineheight24_kh lightgray size15_kh'><?php echo $row['user_email'];?></span>
            </div>
            <div class='left w100 autor-desc'>
               <?php echo ($row['user_info']);?>
            </div>
        </div>
    <div class='right photo-author'>
        <img class='lazy right' src='<?php echo base_url();?>public/author.san.com/<?php echo $row['user_img'];?>' width='' height='' alt='<?php echo $row['user_kh_fname'].' '.$row['user_kh_lname']?>'/>
    </div>

    <?php } ?>

        <script type="text/javascript">
            $(document).ready(function(){
                $(".readmore").click(function(){
                $(".readmore").hide();
                $(".more").slideToggle("flash");
            });
        });
    </script>
        <div class="bg-rotat"></div>       
    </div> 
    <div class="left w100 more_article_author">
        
    </div>

