<div class="left kh size20_kh lineheight25_kh title_relate_poparticle">    
    <div class="bg_title_center left" style="margin-left:0;">               
        <div class="icon_white">
            <span class="menu lineheight28_kh blue size16_kh">
                ព័ត៌មានទាក់ទង              
            </span> 
        </div>              
    </div>
</div> 
<div class="left w100 visible-slide">
    <div class="news_icon_relate margin_item_b left">
        <div class="img_item_news_small_right left">
            <a href="<?php echo site_url();?>article/<?php echo 1;?>" class="">
                <img class="lazy " data-src="https://image.thmeythmey.com/pictures/2018/03/25/thumb1/front_credit.jpg" width="194" height="" alt="លោក ឯម រៀម ចាក់&#8203;ផ្ដៅ&#8203;ជា&#8203;រូប&#8203;ផ្លែ&#8203;ឈើទាល&#8203;រម្លឹក&#8203;កុមារភាព និង&#8203;ចង់&#8203;ឲ្យ&#8203;ខ្មែរ&#8203;បង្កើន&#8203;ការប្រើប្រាស់&#8203;ផ្ដៅ&#8203;" title="">
            </a>
        </div>
                <div class="right title_item_news_small_right">
                    <span class="left kh lineheight22_kh size16_kh white">
                        <a href="<?php echo site_url();?>article/<?php echo 1;?>" class="sign_articles m3 effect_over">
                           
                        លោក ឯម រៀម ចាក់&#8203;ផ្ដៅ&#8203;ជា&#8203;រូប&#8203;ផ្លែ&#8203;ឈើទាល&#8203;រម្លឹក&#8203;កុមារភាព និង&#8203;ចង់&#8203;ឲ្យ&#8203;ខ្មែរ&#8203;បង្កើន&#8203;ការប្រើប្រ..
                    </a> 
                    <div class="item_of_article_ w100 title_kh lineheight24_kh"> 
                        <span class="size12_kh  comment_icon">
                            <font class="comment_icon">
                                <i class="icon-calendar icon"></i>
                                <span class="comment_icon"> 34 នាទី </span>
                            </font>
                        </span>
                    </div>
                </span>
            </div>
        </div>
           
    <div class="news_icon_relate margin_item_b left  margin_l">
        <div class="img_item_news_small_right left">
            <a href="<?php echo site_url();?>article/<?php echo 1;?>" class="">
                <img class="lazy " data-src="https://image.thmeythmey.com/pictures/2018/03/25/thumb1/front_credit.jpg" width="194" height="" alt="លោក ឯម រៀម ចាក់&#8203;ផ្ដៅ&#8203;ជា&#8203;រូប&#8203;ផ្លែ&#8203;ឈើទាល&#8203;រម្លឹក&#8203;កុមារភាព និង&#8203;ចង់&#8203;ឲ្យ&#8203;ខ្មែរ&#8203;បង្កើន&#8203;ការប្រើប្រាស់&#8203;ផ្ដៅ&#8203;" title="">
            </a>
        </div>
                <div class="right title_item_news_small_right">
                    <span class="left kh lineheight22_kh size16_kh white">
                        <a href="indexa05a.html?page=<?php echo site_url();?>article/<?php echo 1;?>;id=63044" class="sign_articles m3 effect_over">
                            
                        លោក ឯម រៀម ចាក់&#8203;ផ្ដៅ&#8203;ជា&#8203;រូប&#8203;ផ្លែ&#8203;ឈើទាល&#8203;រម្លឹក&#8203;កុមារភាព និង&#8203;ចង់&#8203;ឲ្យ&#8203;ខ្មែរ&#8203;បង្កើន&#8203;ការប្រើប្រ..
                    </a> 
                    <div class="item_of_article_ w100 title_kh lineheight24_kh"> 
                        <span class="size12_kh  comment_icon">
                            <font class="comment_icon">
                                <i class="icon-calendar icon"></i>
                                <span class="comment_icon"> 34 នាទី </span>
                            </font>
                        </span>
                    </div>
                </span>
            </div>
        </div>
         <div class="news_icon_relate margin_item_b left  margin_l">
        <div class="img_item_news_small_right left">
            <a href="<?php echo site_url();?>article/<?php echo 1;?>" class="">
                <img class="lazy " data-src="https://image.thmeythmey.com/pictures/2018/03/25/thumb1/front_credit.jpg" width="194" height="" alt="លោក ឯម រៀម ចាក់&#8203;ផ្ដៅ&#8203;ជា&#8203;រូប&#8203;ផ្លែ&#8203;ឈើទាល&#8203;រម្លឹក&#8203;កុមារភាព និង&#8203;ចង់&#8203;ឲ្យ&#8203;ខ្មែរ&#8203;បង្កើន&#8203;ការប្រើប្រាស់&#8203;ផ្ដៅ&#8203;" title="">
            </a>
        </div>
                <div class="right title_item_news_small_right">
                    <span class="left kh lineheight22_kh size16_kh white">
                        <a href="<?php echo site_url();?>article/<?php echo 1;?>" class="sign_articles m3 effect_over">
                            
                        លោក ឯម រៀម ចាក់&#8203;ផ្ដៅ&#8203;ជា&#8203;រូប&#8203;ផ្លែ&#8203;ឈើទាល&#8203;រម្លឹក&#8203;កុមារភាព និង&#8203;ចង់&#8203;ឲ្យ&#8203;ខ្មែរ&#8203;បង្កើន&#8203;ការប្រើប្រ..
                    </a> 
                    <div class="item_of_article_ w100 title_kh lineheight24_kh"> 
                        <span class="size12_kh  comment_icon">
                            <font class="comment_icon">
                                <i class="icon-calendar icon"></i>
                                <span class="comment_icon"> 34 នាទី </span>
                            </font>
                        </span>
                    </div>
                </span>
            </div>
        </div>
           
</div>         
    <div class="pagination_ctn left"><!-- pagination -->
        <div class='sabrosus en size13_en'>
            <span class='disabled'>prev</span>
            <span class='current'>1</span>
            <a href='indexa2e3.html?page=<?php echo site_url();?>article/<?php echo 1;?>;id=63020&amp;paginate=2'>2</a>
            <a href='index4e1b.html?page=<?php echo site_url();?>article/<?php echo 1;?>;id=63020&amp;paginate=3'>3</a>
            <a href='indexa2e3.html?page=<?php echo site_url();?>article/<?php echo 1;?>;id=63020&amp;paginate=2'>next</a>
        </div>     
    </div><!-- end pagination -->           
           