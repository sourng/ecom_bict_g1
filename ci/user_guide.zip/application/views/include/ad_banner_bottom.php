               
                                       
<div id="advertise_id" class="left advertise_bar_bottom visible-md">  
    <div id="block_ad" class="advertise_bottom" style="">
        <div id="" class="advertise_bar_button_close" ><img src="<?php echo base_url();?>public/bgimgs/down.png" onclick="bottom_ads(this)" /></div>
        <div id='banner_273' class='ad_banner  right ' onclick="myFunctionClick('273','http://www.amkcambodia.com/index.html')"><img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/273/697_o.jpg' width='1280' height=70 alt='AMK MFI - Browser PC'  class='img-responsive'/><script type='text/javascript'> impression(273);</script></div>                                            
    </div>
</div>
  
                <script>
                    //advertis bottom
                    var pause = false;
                    function bottom_ads(button){
                		if(pause){
                			$(button).attr("src", "<?php echo base_url();?>public/bgimgs/down.png");
                            $("#block_ad").css({"bottom": "0px","position": "absolute","left":"0"});
                			pause = false;
                		}else{
                			$(button).attr("src", "<?php echo base_url();?>public/bgimgs/up.png");
                			$("#block_ad").css({"bottom": "-60px","position": "absolute","left":"0"});
                            pause = true;
                		}
                	}                   
                </script>  