 <?php include_once 'function.php'; ?>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />                 
    
    <!-- FOR SEO RANKING -->
    <title>san.com </title>
    <link rel="SHORTCUT ICON" type="imgs/png" href="<?php echo base_url();?>public/icon.san.com/logo.png"/>    
    <meta name="description" content="សារព័ត៌មាន​ san.com ​ជា​គេហទំព័រ​ព័ត៌មាន"/>
    <meta name="keywords" content="សារព័ត៌មាន san.com, san.com, cambodia, កម្ពុជា, ខ្មែរ, នយោបាយ, សម្តេច ហ៊ុន សែន, សម រង្ស៊ី, Hun Sen, Sam Rainsy, មោទកភាព, អង្គរសង្ក្រាន្ត, អង្គរវត្ត, បេតិកភណ្ឌ, សហរដ្ឋអាមេរិក, ចិន, វិថីសូត្រ, ទេសចរណ៍, ចរាចរណ៍, បាយ័ន, អប្សរា, Kingdom of Wonder, Go Go Cambodia, សីហនុ, ព្រះបរមរាជវាំង, កឹម សុខា, វ្លាឌីមៀ ពូទីន, ដូណាល់ ត្រាំ, ស៊ី ជិនភីង, សីលធម៌, ជប៉ុន, ភ្នំពេញ,​សៀមរាប, បាត់ដំបង, ឧត្តរមានជ័យ, ត្បូងឃ្មុំ, បន្ទាយមានជ័យ, ព្រះវិហារ, កំពង់ស្ពឺ, កំពង់ឆ្នាំង, កំពង់ធំ, ពោធិ៍សាត់, ក្រចេះ, ស្ទឹងត្រែង, កំពត, កែប, ព្រះសីហនុ, មណ្ឌលគិរី, រតនគិរី, កណ្តាល, ព្រៃវែង, ស្វាយរៀង, ប៉ៃលិន, កំពង់ចាម, Phnom Penh, Battambang, Oddar Meanchey, Thbong Khmum, Banteay Meanchey, Preah Vihear, Kompong Speu, Kompong Chhnang, Kompong Thom, Pursat, Kratie, Stung Treng, Kampot, Kep, Preah Sihanouk, Mondulkiri, Rattanakiri, Kandal, Prey Veng, Svay Rieng, Pailin, Kompong Cham, Koh Kong, កោះកុង, ព្រះបរមរតនកោដ្ឋ, អ៊ឹង ចំរើន, Startup, ក្រុមហ៊ុន, Khmer Media, នយោបាយ, បដិវត្តន៍ពណ៌, ហេង សំរិន, កាហ្វេ, ប្រេនប្រេន,"/>
    <!-- END SEO RANKING -->  

    <!-- FOR FACEBOOK SHARE -->    
    <meta property="fb:app_id" content="1429436070672076" />
    <meta property="og:type" content="website" /> 
    <meta property="og:url" content="https://thmeythmey.com:443/" />
    <meta property="og:site_name" content="ThmeyThmey.com"/>
    <meta property="og:locale" content="km_KH" />
    <meta property="og:title" content="Thmey Thmey" />
    <meta property="og:description" content="សារព័ត៌មាន​ថ្មីៗ ​ជា​គេហទំព័រ​ព័ត៌មាន ប្រកាន់ខ្ជាប់គោលការណ៍​អព្យាក្រឹត និងឯករាជ្យ នៅ​ក្នុង​បេសកកម្ម​ផ្តល់ព័ត៌មាន​ពិត មិន​លំអៀង និង​ស៊ីជម្រៅ តាម​រយៈ​អត្ថបទ​ បទយកការណ៍ បទវិភាគ និង​ព័ត៌មាន​ទាន់ហេតុការណ៍ ប្រកបដោយវិជ្ជាជីវៈ។ www.thmeythmey.com which is a news online​ respect fully the" />
    <meta property="og:image" content="<?php echo base_url();?>public/thmeythmey_logo.jpg" />    
    <!-- END FACEBOOK SHARE -->

    <!-- AppStore ID for iOS -->
    <meta name="apple-itunes-app" content="app-id=833433044"/>
    <!-- Play Store ID for Android -->
    <meta name="google-play-app" content="app-id=com.cammob.thmeythmey"/>    
    <!-- Start Alexa Certify Javascript-->
    <!-- End Alexa Certify Javascript -->
    <!-- iOS AppLink Connect -->
    <meta property="al:ios:url" content="thmeythmey://article/" />
    <meta property="al:ios:app_store_id" content="833433044" />
    <meta property="al:ios:app_name" content="ThmeyThmey" />

    <!-- Android AppLink Connect -->
    <meta property="al:android:url" content="thmeythmey://article/">
    <meta property="al:android:package" content="com.cammob.thmeythmey"/>
    <meta property="al:android:app_name" content="ThmeyThmey"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
     
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>  
    <!-- <script type="text/javascript">
        var _gaq=_gaq||[];_gaq.push(["_setAccount","UA-30328839-1"]);_gaq.push(["_trackPageview"]);(function(){var e=document.createElement("script");e.type="text/javascript";e.async=true;e.src=("https:"==document.location.protocol?"https://ssl":"http://www")+".google-analytics.com/ga.js";var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t)})()
    </script> -->
      
    <script src="<?php echo base_url();?>public/jquery/jQuery-v1.10.2.js"></script>  
    <!-- Push Notification-->
    <!-- <link rel="manifest" href="manifest.json"/>
    <script src="cdn.onesignal.com/sdks/OneSignalSDK.js" async></script>
    <script>
        var OneSignal = OneSignal || [];
        OneSignal.push(["init", {
            appId: "3ae544b0-d2e8-41d2-986e-f1c69217ebe7",
            autoRegister: true,
            notifyButton: {
                enable: false
            }
        }]);
    </script>     -->    
    <!-- End Push Notification -->             
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/jsfunction8e0e.js?v=8"></script>    
    <link rel='stylesheet' type='text/css' href='<?php echo base_url();?>public/css/all2048.css?v=1.5'/> 
    <link rel="stylesheet" type='text/css' href="<?php echo base_url();?>public/css/bootstrap3cc5.css?v=1.6"/>     
    <link href="feed/index.html" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
    <link href="feed/index.html" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
    <!--- END FOR MAKE AUTO CENTER -->
    <!--cssicon-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/icon1bce.css?v=6" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/animation30f4.css?v=3" />    
    <!-- drop down menu -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/ddmenu/ddsmoothmenubea6.css?v=7" />    
    <!--<link rel="stylesheet" type="text/css" href="ddmenu/ddsmoothmenu-v.css?v=3" />-->

    <!--  <script async src="platform.twitter.com/widgets.js" charset="utf-8"></script>                  
    <script async defer src="www.instagram.com/static/bundles/base/EmbedSDK.js/ddd5d9d2433c.js"></script>  -->   
    <link type='text/css' href="<?php echo base_url();?>public/plugin/detail_pop_up/css3860.css?v=1" rel="stylesheet"/>   


    <script type="text/javascript" src="<?php echo base_url();?>public/ddmenu/ddsmoothmenu5e1f.js?v=2"></script>
    <script type="text/javascript">
        ddsmoothmenu.init({
        	mainmenuid: "smoothmenu", 
        	orientation: 'h', 
        	classname: 'ddsmoothmenu',      	
        	contentsource: "markup" 
        })  
    </script>                    
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/js_search.js"></script>     
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/jquery.carouFredSel-5.5.0.js"></script>
    <!-- Jalendar files -->
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/jalendar.css?v=4" type="text/css" />    
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/jalendar.min.js"></script>
    <!-- Jalendar files #end -->      
    <style>#ad_root{display:none;font-size:14px;height:250px;line-height:16px;background-color:#ccc;position:relative;width:300px;align-items:center;margin-left:auto;margin-right:auto}.thirdPartyMediaClass{height:157px;width:300px}.thirdPartyTitleClass{font-weight:600;font-size:16px;margin:8px 0 4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#000!important}.thirdPartyBodyClass{display:-webkit-box;height:32px;-webkit-line-clamp:2;overflow:hidden;color:#000!important}.thirdPartyCallToActionClass{color:#326891;font-family:sans-serif;font-weight:600;margin-top:8px}</style>
    <!--print text-->
    <script type="text/javascript">
        //advertise click
        function myFunctionClick(ads_click_id,url) {              
            $.post('https://a.thmeythmey.com/trackit.php',{tid:ads_click_id});
            window.open(url,'_blank');                                                
        }                                                   
        //end advertise click                
        function impression(ads_id){             
            var scrolltop=getScrollTop();
            var advZoneTop=getElementTop('banner_'+ads_id);
            if((scrolltop+windowPrototype.wdHeight())>advZoneTop){                                                
                $.post('https://a.thmeythmey.com/impression.php',{ advertise_id:ads_id})                                                                                                                                 
            }else{ setTimeout('impression('+ads_id+')',100);}
        }                                                                     
    </script>   
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/jquery.infinitecarousel.3.3.js"></script>           
    <script type="text/javascript">
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','<?php echo base_url();?>public/www.google-analytics.com/analytics.js','ga');        
        ga('create', 'UA-60790722-2', 'auto');
        ga('send', 'pageview');    
    </script>    
    <style type="text/css">.fixed_topmenu{position: fixed;top: 0px;z-index:40;}</style>    
    <!--add this-->            
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/impression.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/jquery_search5e1f.js?v=2"></script> 
    <!--bootstrap-->       
    <script type="text/javascript" src="<?php echo base_url();?>public/plugin/slidehotnews/jquery.accessible-news-slider7b30.js?v=4"></script>     
    <!-- Google Tag Manager -->
    <!-- <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-TKQWW2S');</script> -->
    <!-- End Google Tag Manager -->
    <link rel='stylesheet' type='text/css' href="<?php echo base_url();?>public/css/host_news_style30f4.css?v=3" />
    <link rel="stylesheet" href="<?php echo base_url();?>public/css/audioplayer3860.css?v=1" />				
    <script src="<?php echo base_url();?>public/jquery/audioplayer.js"></script>
    <script>$( function() { $( 'audio' ).audioPlayer(); } );</script>
    <script type="text/javascript" src="<?php echo base_url();?>public/jquery/addthis.js"></script> 
   

    