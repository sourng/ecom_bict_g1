<div style="width: 100%;min-height:200px;" class="hot_news_block_pc left">        
    <div class="hot_news_block left wow fadeInDown animated w100" style="visibility: visible; animation-name: fadeInDown;">
  <?php 
   $i=1;
  foreach($feature_big as $row){ 
    if ($i==1) {
      ?>
       <div class='left hot_news_lg'>    
          <div class='bg_title_blur effect_over'>        
            <div class='right title_sm'>            
              <a href='<?php echo site_url();?>article/<?php echo $row['art_id'];?>' class='left effect_over  m5'>
                <span class='left title_kh lineheight34_kh'>
                 <?php echo $row['art_title'];?>
                </span>
              </a>            
                <span class='left title_kh lineheight36_kh size13_kh w100 icon'>  <span class='sign_article title_kh left size12_kh '>  
                </span> 
                <i class='icon-time icon size12_kh'></i> <?php echo time_ago($row['art_date']);?></span>        
            </div>    
        </div>    
        <img  data-src='<?php echo base_url();?>public/image.san.com/<?php echo $row['art_feature_img'];?>' 
        class='lazy' width='500' height='' alt='<?php echo $row['art_title'];?>' title=''/>
      </div>
      <?php
    }elseif ($i==2) {
      ?>
        <div class='right hot_news_lg'>    
          <div class='bg_title_blur effect_over'>        
            <div class='right title_sm'>            
              <a href='<?php echo site_url();?>article/<?php echo $row['art_id'];?>' class='left effect_over  m5'>
                <span class='left title_kh lineheight34_kh'>
                 <?php echo $row['art_title'];?>
                </span>
              </a>            
                <span class='left title_kh lineheight36_kh size13_kh w100 icon'>  <span class='sign_article title_kh left size12_kh '>  
                </span> 
                <i class='icon-time icon size12_kh'></i> <?php echo time_ago($row['art_date']);?></span>        
            </div>    
        </div>    
        <img  data-src='<?php echo base_url();?>public/image.san.com/<?php echo $row['art_feature_img'];?>' 
        class='lazy' width='500' height='' alt='<?php echo $row['art_title'];?>' title=''/>
      </div>
      <?php
    }elseif ($i==3) {
      ?>
       <div class='right  hot_news_sm'>    
      <div class='bg_title_blur effect_over'>        
        <div class='right title_sm'>            
          <a href='<?php echo site_url();?>article/<?php echo $row['art_id'];?>' class='left effect_over  m5'>
            <span class='left title_kh lineheight24_kh size14_kh'>
             <?php echo $row['art_title'];?>
             </span>
          </a>            
          <span class='left title_kh lineheight30_kh size13_kh w100 icon'>
            <span class='sign_article title_kh left size12_kh '> កំពង់ឆ្នាំង </span> 
            <i class='icon-time icon size12_kh'></i> <?php echo time_ago($row['art_date']);?>
          </span>        
        </div>    
    </div>    
    <img  data-src='<?php echo base_url();?>public/image.san.com/<?php echo $row['art_feature_img'];?>' class=' lazy' width='332' height='' alt=' <?php echo $row['art_title'];?>' title=''/>
    </div>
      <?php
    }else {
      ?>
        <div class='left margin_r_h hot_news_sm'>    
        <div class='bg_title_blur effect_over'>        
          <div class='right title_sm'>            
            <a href='<?php echo site_url();?>article/<?php echo $row['art_id'];?>' class='left effect_over  m5'>
              <span class='left title_kh lineheight24_kh size14_kh'>
                 <?php echo $row['art_title'];?>
                <span class='sign_article kh lineheight15_kh red'>កំណាព្យ</span>  
              </span>
            </a>            
            <span class='left title_kh lineheight30_kh size13_kh w100 icon'> 
              <span class='sign_article title_kh left size12_kh '>  </span> 
              <i class='icon-time icon size12_kh'></i> <?php echo time_ago($row['art_date']);?>
            </span>        
             </div>    
        </div>    
        <img  data-src='<?php echo base_url();?>public/image.san.com/<?php echo $row['art_feature_img'];?>' class=' lazy' width='332' height='' alt=' <?php echo $row['art_title'];?>' title=''/>
      </div>
      <?php
    }
    $i=$i+1;
  }
?>


      
      
    </div>
       
</div>