<?php  
  date_default_timezone_set('Asia/Phnom_Penh');
  // time_ago 
  function time_ago($timestamp){  
      
      $time_ago = strtotime($timestamp);  
      $current_time = time();  
      $time_difference = $current_time - $time_ago;  
      $seconds = $time_difference;  
      $minutes      = round($seconds / 60 );           // value 60 is seconds  
      $hours           = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec  
      $days          = round($seconds / 86400);          //86400 = 24 * 60 * 60;  
      $weeks          = round($seconds / 604800);          // 7*24*60*60;  
      $months          = round($seconds / 2629440);     //((365+365+365+365+366)/5/12)*24*60*60  
      $years          = round($seconds / 31553280);     //(365+365+365+365+366)/5 * 24 * 60 * 60  
      if($seconds <= 60)  
      {  
     return "1 វិនាទី";  
   }  
      else if($minutes <=60)  
      {  
     if($minutes==1)  
           {  
       return "1​នាទី";  
     }  
     else  
           {  
       return $minutes." នាទី";  
     }  
   }  
      else if($hours <=24)  
      {  
     if($hours==1)  
           {  
       return "1 ម៉ោង";  
     }  
           else  
           {  
       return $hours." ម៉ោង";  
     }  
   }  
      else if($days <= 7)  
      {  
     if($days==1)  
           {  
       return "1 ថ្ងៃ";  
     }  
           else  
           {  
       return $days." ថ្ងៃ";  
     }  
   }  
      else if($weeks <= 4.3) //4.3 == 52/12  
      {  
     if($weeks==1)  
           {  
       return "1 សប្តាហ៍";  
     }  
           else  
           {  
       return $weeks." សប្តាហ៍";  
     }  
   }  
       else if($months <=12)  
      {  
     if($months==1)  
           {  
       return "1 ខែ";  
     }  
           else  
           {  
       return $months." ខែ";  
     }  
   }  
      else  
      {  
     if($years==1)  
           {  
       return "1 ឆ្នាំ";  
     }  
           else  
           {  
       return $years." ឆ្នាំ";  
     }  
   }  
 }  
// End time_ago 


 function short_title($old_string,$limit_word){
   // strip tags to avoid breaking any html
   $string = strip_tags($old_string);

   if (strlen($string) > $limit_word) {

       // truncate string
       $stringCut = substr($string, 0, $limit_word);

       // make sure it ends in a word so assassinate doesn't become ass...
       $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
   }
   return($string);
  }


/*get one*/
 function get_col($sql){
  global $conn;
  if(strpos(strtoupper($sql), 'LIMIT') === false) {
    $sql .= " LIMIT 1";
  }
  $query = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($query);
  return $row[0];
}
  /* trimleft time*/
function trimleft_time($datetime)
{
$datetime =  substr($datetime,0,-3);
return $datetime;
}


/*replace*/
function replace_tag($string)
 {
$string = str_replace('<','&lt;',$string);
$string = str_replace('>','&gt;',$string);
$string = str_replace('`','&#96;',$string);
$string = str_replace("'","&#39;",$string);
$string = str_replace('"','&quot;',$string);
$string = str_replace('{','&#123;',$string);
$string = str_replace('}','&#125;',$string);
$string = str_replace('?','&#63;',$string);
$string = str_replace('@','&#64;',$string);
return $string;
}
function add_path($string)
 {
$string = str_replace('@add_path@/',base_url(),$string);
return $string;
}
function active($currect_page){
  $url_array =  explode('san.com/', $_SERVER['REQUEST_URI']) ;
  $url = end($url_array);  
  if($currect_page == $url){
      return ('current'); //class name in css 
  }
}
function categories_name($cat)
 {
        return($cat);
 } 
 
function cvf_ps_generate_random_code($length=10) {
 
   $string = '';
   // You can define your own characters here.
   $characters = "0123456789_ABCDEFHJKLMNPRTVWXYZ_abcdefghijklmnopqrstuvwxyz_";
 
   for ($p = 0; $p < $length; $p++) {
       $string .= $characters[mt_rand(0, strlen($characters)-1)];
   }
 
   return $string;
 
}
//echo cvf_ps_generate_random_code('10');
function detectDevice(){
   $userAgent = $_SERVER["HTTP_USER_AGENT"];
   $devicesTypes = array(
         "computer" => array("msie 10", "msie 9", "msie 8", "windows.*firefox", "windows.*chrome", "x11.*chrome", "x11.*firefox", "macintosh.*chrome", "macintosh.*firefox", "opera"),
         "tablet"   => array("tablet", "android", "ipad", "tablet.*firefox"),
         "mobile"   => array("mobile ", "android.*mobile", "iphone", "ipod", "opera mobi", "opera mini"),
         "bot"      => array("googlebot", "mediapartners-google", "adsbot-google", "duckduckbot", "msnbot", "bingbot", "ask", "facebook", "yahoo", "addthis")
     );
   foreach($devicesTypes as $deviceType => $devices) {           
         foreach($devices as $device) {
             if(preg_match("/" . $device . "/i", $userAgent)) {
                 $deviceName = $deviceType;
             }
         }
     }
     return ucfirst($deviceName).' : <br>'. $_SERVER['HTTP_USER_AGENT'].' <br>'.$_SERVER['REMOTE_ADDR'];;
   }
  return detectDevice()
  ?> 
  