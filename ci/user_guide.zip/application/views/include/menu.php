 <div class="werrapper_header"><!--- HEADER CONTAINER -->                                
            <?php //include_once 'include/title.php';?>
            <div class="header_ctn left w100">            
                <div class="header_logo_title">
                    <div class="logo_title dspblock"><!--logo_cmp_title-->      
                        <div class="logo_ctn left"><!--logo-->                                            
                            <a href="<?php echo site_url();?>#logo" class="left">
                                <img src="<?php echo base_url();?>public/icon.san.com/logo.png" alt="" width="111" height="111" alt="san.com"/>
                            </a>         
                        </div><!--end logo-->    
                        <div class="advertis_header">                
                            <div id='banner_345' class='ad_banner  right ' onclick="myFunctionClick('345','index.html')"><img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/345/760x100-ttn-free.gif' width='760' height= alt='ThmeyTHmey'  class='img-responsive'/><script type='text/javascript'> impression(345);</script></div>            </div>     
                    </div><!--end logo_cmp_title--> 
                </div>
            </div> 
<!--menu-->  

<div id="fixed_menu" class="left w100">
    <div class="dspblock menu_ctn w100 left">                      
        <div id="smoothmenu" class="ddsmoothmenu" ><!-- drop down menu -->
            <ul>
                <li>
                    <a id='active_menu' class='<?php echo active('home') ?>' href="<?php echo site_url();?>home">
                        <span class="middle effect_over">
                            <font class="menu ">
                                <i class="icon-home size24_kh"></i>
                            </font>
                        </span>
                    </a>
                </li>
            </ul>
            <?php foreach ($categories as $row) { ?>
            <ul>
                <li>
                    <a class="<?php echo active('page/'.$row['cat_id']) ?>" href='<?php echo site_url();?>page/<?php echo($row['cat_id']) ?>'>
                        <span class='middle effect_over'>
                            <font class='menu size16_kh lineheight28_kh ' ><?php echo($row['cat_kh_name']) ?></font>
                        </span>
                    </a>
                    <!-- <ul>
                        <li>
                            <a class='effect_over' href='indexbb1e.html?page=location&amp;menu1=3&amp;menu2=4870&amp;id=43'>
                                <font class='menu lineheight20_kh size14_kh'>ព្រំដែន</font>
                            </a>
                        </li>                        
                    </ul> -->
                </li>
            </ul>
            <?php } ?>

            <div class="absolute-r menu_sm btn_search_pc" onclick=""><i class="icon-search size20_kh lightblue"></i></div>
            <div class="form_search_pc right"><!-- SEARCH-->
                    <style type="text/css"> 
        .form_search_pc{width:378px;height:70px;display:none}.bg_search_art{float:left;width:350px;height:auto;background:0 0;margin:2px 0 0;position:relative}.bg_search_art .field_search{margin-bottom:13px;position:relative}#tabs,#tabs a::after,.btn_search{position:absolute}.bg_search_art .form-control{width:250px;padding-right:42px}.btn_search{width:40px;background:#055c9f;color:#fff;border:1px solid #055089;padding:5px 0;text-align:center;cursor:pointer;border-bottom-right-radius:3px;border-top-right-radius:3px;top:0;bottom:0;right:0}#content,#tabs a{position:relative}.btn_search:hover{background:#076ab8;border:1px solid #055089;color:#fff}#tabs #current a,#tabs a{border-top:1px solid #055089;border-left:0 solid #055089;border-right:1px solid #055089;border-bottom:1px solid #055089}#tabs{overflow:hidden;width:30px;margin:0;padding:0;list-style:none;right:-29px;top:6px;z-index:3}#tabs li{float:left;margin:0px;margin-bottom:2px}#tabs a{background:#055c9f;padding:.2em .5em;float:left;text-decoration:none;color:#fff;-moz-border-radius:0 3px 3px 0;-webkit-border-radius:0 3px 3px 0;border-radius:0 3px 3px 0}#tabs a:focus,#tabs a:focus::after,#tabs a:hover,#tabs a:hover::after{background:#fff;color:#076cb8}#tabs a:focus{outline:0}#tabs a::after{content:'';z-index:1;top:0;right:0;bottom:0;width:0;background:#055c9f;color:#076cb8}#tabs #current a{color:#076cb8}#tabs #current a,#tabs #current a::after{background:#fff;z-index:3;position:relative}#content{background:#fff;padding:1em 1.5em;height:auto;z-index:2;-moz-box-shadow:0 -2px 3px -2px #055089;-webkit-box-shadow:0 -2px 3px -2px #055089;box-shadow:inset 0 0 0 1px #055089;top:-1px}#content #tab1{min-height:36px}#content #tab2{min-height:100px}#content h2,#content h3,#content p{margin:0 0 15px}                                              
   </style>
   <div class="bg_search_art">               
       <ul id="tabs">            
            <li class="title_kh size14_kh lineheight18_kh "><a href="#" title="tab1" class="effect_over"><i class="icon-edit"></i></a></li>
            <li class="title_kh size14_kh lineheight18_kh "><a href="#" title="tab2" class="effect_over"><i class="icon-calendar"></i></a></li>
        </ul>        
        <div id="content"> 
            <div id="tab1" class="block_tap">
                <form name="asearch" action="#" method="post">
                    <div class="left field_search">                                         
                        <input type="text" name="txt_asearch" value="" placeholder="ស្វែងរក" onkeydown="if (event.keyCode == 13)searchContent('kh','Please enter your keyword..!','');" onfocus="this.value='';" class="form-control dark_desc lineheight20_kh size14_kh kh"/>                                                                                                
                        <div onclick="searchContent('kh','Please your keyword..!','Please your keyword..!');" class="effect_over right btn_search size14_kh title_kh lineheight24_kh"><i class='icon-search'></i></div>                                                                                    
                    </div>
                </form>                   
            </div>
            <div id="tab2" class="block_tap" style="display: none;">                                            
                <div id="yourId2" class="jalendar"></div>    
                <script>
                    $('#yourId2').jalendar({
                        color: '#fff',
                        type: 'linker',
                        customUrl: 'search.php?s=',
                        dateType: 'yyyy-mm-dd',
                        titleColor: '#666',
                        weekColor: '#EA5C49',
                        todayColor: '#EA5C49'
                    });
                </script>                                                                                                        
            </div> 
               
        </div>        
        <!--
        <div class="radio_block_front w100 left ">
                    </div>             
        -->
    </div>          
     </div><!--end SEARCH--> 
        </div><!-- end drop down menu -->                                                                                      
                                                      
    </div>
</div><!--end menu--> 
       
<!-- <script type="text/javascript">                                            
    (function(){
        var hexacode = ['#00a2ee','#044d85'],
        el = document.getElementById('effect_menu').style,
        counter = -1,
        hexalen = hexacode.length;
        function auto(){el.color = hexacode[counter = ++counter % hexalen];
        }setInterval(auto,500);
    })();                                                
</script>       -->                                                                                                                                                     
</div> <!--End Header Container -->

        