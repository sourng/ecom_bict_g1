    <footer>
            <div class="left w100 footer">                           
                <div class="footer_container">
    <div class="block_content_footer">
        <div class="bg_title_center left">                              
            <div class="icon_white">
                <span class="menu lineheight30_kh gray size16_kh">
                    ទំនាក់ទំនង              
                </span> 
            </div>                                  
        </div>
        <div class="left w100 detail_footer">
            <div class="icon_footer left gray"><i class="icon-home size20_kh"></i></div>                            
            <div class="content_footer left lightgray kh size14_kh lineheight20_kh">លីឡាក្លឹបកំសាន្ត, ជាន់ទី១, ផ្ទះលេខ៣៦, ផ្លូវលេខ ៥០៨, សង្កាត់ ផ្សារដើមផ្គូវ ខណ្ខ ចំការមន, ភ្នំពេញ</div>            
        </div>
        <div class="left w100 detail_footer">
            <div class="icon_footer left gray"><i class="icon-phone-sign size18_kh"></i></div>                            
            <div class="content_footer left lightgray en size14_kh lineheight18_kh">(+855) 969 140 554</div>            
        </div>
        <div class="left w100 detail_footer">
            <div class="icon_footer left gray"><i class="icon-envelope size16_kh"></i></div>                            
            <div class="content_footer left lightgray en size14_kh lineheight18_kh">info@san.com</div>            
        </div>
    </div>
    <div class="block_content_footer_download">
        <div class="bg_title_center left">                              
            <div class="icon_white">
                <span class="menu lineheight30_kh gray size16_kh">
                    ទាញយកព័ត៌មានគេហទំព័រថ្មីៗ              
                </span> 
            </div>                                  
        </div>
        <div class="left w100 detail_footer">
            <div class="left"><a href="https://itunes.apple.com/kh/app/thmeythmey/id833433044?mt=8" target="_blank"><img src="<?php echo base_url();?>public/bgimgs/download_app_store.png" width="131" height="44" alt="Download App Store" /></a></div>
            <div class="right"><a href="https://play.google.com/store/apps/details?id=com.cammob.thmeythmey" target="_blank"><img src="<?php echo base_url();?>public/bgimgs/Google-Play-button.png" width="131" height="44" alt="Download Play Store" /></a></div>            
        </div>        
    </div>
    <div class="block_content_footer_socail">
        <div class="bg_title_center left">                              
            <div class="icon_white">
                <span class="menu lineheight30_kh gray size16_kh">
                    ភ្ជាប់ជាមួយយើងតាមរយៈ              
                </span> 
            </div>                                  
        </div>
        <div class="left w100 detail_footer dark size20_kh">
            <div class="icon_socail left"><a href="#no" target="_blank" class="m3 effect_over"><i class="icon-facebook"></i></a></div>  
            <div class="icon_socail left"><a href="#no" target="_blank" class="m3 effect_over"><i class="icon-twitter"></i></a></div>
            <div class="icon_socail left"><a href="#no" target="_blank" class="m3 effect_over"><i class="icon-instagram"></i></a></div>
            <div class="icon_socail left"><a href="#no" target="_blank" class="m3 effect_over"><i class="icon-youtube"></i></a></div>                                                  
        </div>        
    </div>
    <div class="left w100 hosting">
        <div class="left en size13_kh bold lineheight40_kh gray">&copy; All Rights Reserved & Copyrights by <a href="./" target="_blank" class="uppercase m6">san.com</a> 2018</div>
        <div class="right en size13_kh bold lineheight40_kh gray">Hosting By:&nbsp;&nbsp;<a href="http://digi.com.kh/home/" target="_blank"><img src="<?php echo base_url();?>public/bgimgs/logo_digi.gif" width="" height="" alt="San Hosting" /></a></div>
    </div>
    <div class="clear"></div>
</div>
                    
            </div>  
        </footer>                 
    </div><!--end page container-->
    <script src="<?php echo base_url();?>public/jquery/jquery.lazy.1.js"></script> 
    <script src="<?php echo base_url();?>public/jquery/wow.min.js"></script>
    <script src="<?php echo base_url();?>public/jquery/custom3860.js?v=1"></script>
    <script src="<?php echo base_url();?>public/jquery/smoothscroll.js"></script>        
    <!-- end: HOT NEWS BOTTOM --> 
   


          
    <div id="goto_top" style="position: fixed;bottom:150px;right:15px;display:none;z-index:11">
        <div class="bottom_up">
            <a class="effect_over" href="javascript:" onclick="$('html, body').animate({scrollTop: 0},1000);"> <i class="icon-chevron-up size15_en lineheight18_kh"></i> </a>
        </div>
    </div>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TKQWW2S"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
