<div class="add_left visible-lg">
                    <div id="fixed_ad"><!--fix menu-->  
                        <div class="ad_left_right left">
                            <div id='banner_34' class='ad_banner  right ' onclick="myFunctionClick('34','index.html')"><img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/34/free_add11_130x550.jpg' width='130' height=550 alt='ThmeyThmey'  class='img-responsive'/><script type='text/javascript'> impression(34);</script>
                            </div>    
                        </div>    
                    </div>      
                </div>      