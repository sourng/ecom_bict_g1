 <div class="add_right visible-lg"><!--ad left body-->
        <div id="fixed_adr"><!--fix menu-->
                                                                                                                                                                                   
	    <div class="ad_left_right right" style='width:130px;'>     
	         <div id='banner_35' class='ad_banner  right ' onclick="myFunctionClick('35','https://www.maxbit.com.kh/')"><img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/35/23845428_1608594109179377_798723699_n.jpg' width='130' height=550 alt='Maxbit'  class='img-responsive'/><script type='text/javascript'> impression(35);</script></div>    
	     </div>
        </div>
      </div>     