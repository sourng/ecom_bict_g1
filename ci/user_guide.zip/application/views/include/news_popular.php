<!--populer news-->
<div class="werrapper_block_news w100 left">                      
    <div class="bg_title_center_r left">                                
        <div class="icon_white">
            <span class="menu lineheight28_kh blue size16_kh">
                អត្ថបទពេញនិយម              
            </span> 
        </div>                             
    </div>                                                                                                   
    <div class="new_block_body_r left wow fadeInDown">          
        <div class="new_block_body_in left">
            <?php 
            foreach ($popular as $row) { ?>
                <div class='news_icon margin_item_b left left '>
                <div class='img_item_news_small_right left lazy'>
                    <a href='<?php echo site_url();?>article/<?php echo ($row['art_id']);?>' class='left'>
                        <img class='lazy' data-src='<?php echo base_url();?>public/template/timthumb.php?src=<?php echo base_url()."public/image.san.com/".$row['art_feature_img']."&w=230&h=150&q=100&s";?>' alt=' <?php echo ($row['art_title']);?>' title=''>
                    </a>
                </div>
                <div class='right title_item_news_small_right'>
                    <span class='left kh lineheight22_kh size16_kh white'>
                        <a href='<?php echo site_url();?>article/<?php echo ($row['art_id']);?>' class='sign_articles m3 effect_over'>
                            <?php echo short_title($row['art_title'],250);?>
                        </a> 
                        <div class='item_of_article_ w100 title_kh lineheight22_kh'>   
                            <span class='sign_article title_kh left size12_kh '> </span> 
                            <span class='size12_kh  comment_icon'>
                                <font class='comment_icon'>
                                    <i class='icon-calendar icon size11_kh'></i> 
                                    <span class='comment_icon'> <?php echo time_ago($row['art_date']);?> </span>
                                </font>
                            </span>
                        </div>
                    </span>
                    </div>
                </div>

                <?php } ?>  
           

        </div>                                        
       <!--  <div class="see_more margin_read_more_right effect_over right">
            <span class="search_page_readmore_link  title_kh lineheight40_kh size12_kh">                
                <a href="index9a03.html?page=location&amp;id=top_article">
                    អត្ថបទពេញនិយមបន្ថែម                
                </a>
            </span>
        </div> -->                                                     
    </div>
</div>
<!-- end populer new