<div class="ad_top_big_banner">
                            
        <div class="big left">
        <div id='banner_269' class='ad_banner  right ' onclick="myFunctionClick('269','http://www.hlb.com.kh/')">
            <img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/269/thmey-thmey-w1000px-x-h100pxss.jpg' width='1000' height=100 alt='Hong Leong Bank Plc - Browser PC'  class='img-responsive'/>
            <script type='text/javascript'> impression(269);</script>
        </div>
        <div id='banner_377' class='ad_banner  right ' onclick="myFunctionClick('377','https://www.facebook.com/gais.edu.kh/')">
            <img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/377/sc.gif' width='1000' height= alt='Green Apple International School'  class='img-responsive'/><script type='text/javascript'> impression(377);</script>
        </div>    
        </div><!---End Front Top Big Banner-->  
              
        <!--End Back Top Big Banner-->                       
</div>   
<div hidden="" class="ad_top_big_banner">
                         
    <div class="big left">
                    
            <script type="text/javascript" language="javascript">
                $(window).load(function(){$(function(){$("#foo2_Cam_Asian_PC_Slide").carouFredSel({width:"1000",height:"auto",prev:"#prev2_ad",next:"#next2_ad",auto:!0,direction:"down",scroll:{item:1,duration:1e3,pauseOnHover:!0}})})});             
            </script>
            <style type="text/css" media="all">
                .list_carousel_Cam_Asian_PC_Slide{width:1000px;height:100px;border:0 solid #000;margin:0!important}.list_carousel_Cam_Asian_PC_Slide ul{margin:0;padding:0;list-style:none;display:block;border:0 solid #ff0}.list_carousel_Cam_Asian_PC_Slide li{color:#AC0F18;text-align:center;border:0;width:1000px;height:100px;padding:0;padding-top:0;padding-left:0;margin:0;display:block;float:left;cursor: pointer;border:0 solid #ff0;position:relative;z-index:0}.list_carousel_Cam_Asian_PC_Slide.responsive{width:auto;margin-left:0}.caroufredsel_wrapper_Cam_Asian_PC_Slide{border:0 solid green}           
            </style>
            <!--promot dfdfdf-->                                                                                   
            <div id='banner_205' class='ad_banner  right ' onclick="myFunctionClick('205','https://www.cimbbank.com.kh/km/personal/news-and-promotions/promotions/general/HomePro.html')">
                <img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/205/thmey-thmey-web.jpg' width='1000' height=100 alt='CIMB BANK'  class='img-responsive'/>
                <script type='text/javascript'> impression(205);</script>
            </div>
            <div id='banner_261' class='ad_banner  right ' onclick="myFunctionClick('261','https://www.zamanisc.edu.kh/en/')">
                <img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/261/thmey-w1000-rrrh100.gif' width='1000' height=100 alt='Zaman International School'  class='img-responsive'/>
                <script type='text/javascript'> impression(261);</script>
            </div>
            <div class='right ad_banner ' style='width:1000px;height:100px;position:relative;'>
                <div class='promotion'>
                    <div class='list_carousel_Cam_Asian_PC_Slide' style='position:relative; top:0px; left:0px;'>
                        <div class='caroufredsel_wrapper_Cam_Asian_PC_Slide' style='height:100px; width:1000px;overflow: hidden;'>
                            <ul id='foo2_Cam_Asian_PC_Slide'>
                                <li id='banner_303' onclick="myFunctionClick('303','http://cam-asean.com/young-learner-program/')">
                                    <img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/303/baner-1-sac-.jpg' width=1000 height=100 alt='Cambodia ASEAN International Institute' class='img-responsive'>
                                    <script type='text/javascript'> impression('303'); </script>
                                </li>
                                <li id='banner_353' onclick="myFunctionClick('353','http://cam-asean-training.com/')">
                                    <img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/353/banner-1-ct.jpg' width=1000 height=100 alt='Cam Asean' class='img-responsive'>
                                    <script type='text/javascript'> impression('353'); </script>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>          
    </div>
<!---End Back Top Big Banner-->                       
                    </div>                      