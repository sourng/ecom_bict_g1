 <?php foreach($article as $row){ ?>
 <div class="dspblock whol_lbody_ctn left"><!--lbody-->                 
        <div class="dspblock lpanel_inner left"><!--lpanel--> 
            <div class="werrapper_block_news left">  
                <div class="detail_body_ctn left">            
                <!-- <div class="margin-right tag-hover pointer left btn-info btn-block_2 effect_over" onclick="window.open('index7014.html?page=location&amp;id=9')">
                    <span class="size11_kh lineheight18_kh title_kh">ជាតិ</span>
                </div> -->
               
                <div class='detail_dp_title_ctn left'>
                    <span class='title_kh size24_kh dark lineheight36_kh'>
                   <?php echo $row['art_title'];?>
                    </span>
                    <div class='left w100'>
                        <span class='title_kh gray lineheight30_kh size12_kh'>
                            <i class='icon-calendar size11_kh'></i> <?php echo $row['art_date'];?> , 
                            <i class='icon-time size12_kh'></i> <?php echo $row['art_date'];?> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <i class='icon-eye-open size12_kh'></i> 
                            <?php  foreach ($count_views as $views) {
                              echo $views['views'];
                            } ?> 
                        </span> 
                        <span class='right lineheight30_kh'>
                            <a onclick="return print_text('<?php echo site_url();?>print/<?php echo $row['art_id'];?>')" href='#' class='m4 effect_over'>
                                <i class='icon-print size17_kh'></i>
                            </a>
                        </span>
                    </div>
                    <div class='left w100'>
                        <span class='title_kh gray lineheight40_kh size12_kh'>ដោយ: 
                            <a href='index5e55.html?page=author&amp;id=45' class='m1 size15_kh italic'>
                              <?php echo $row['user_kh_fname'].' '.$row['user_kh_lname'];?></a> 
                        </span>
                    </div>
                </div> 
                <div class='left w100 kh gray size17_kh lineheight16_kh'>
                    <div class='detail_dp_counter_ctn kh size12_kh dark_gray lineheight16_kh'>
                       <div class='left share_addthis_button'> 
                           <div class='addthis_toolbox addthis_default_style addthis_20x20_style'>
                               <a class='addthis_button_twitter'></a>
                               <a class='addthis_button_google_plusone_share'></a>
                               <a class='addthis_button_compact'></a> 
                           </div>
                       </div>

                       <div class='fb-share-button right' 
                       data-href='https://thmeythmey.com/?page=detail&id=63020&action=share' data-layout='button_count' data-mobile-iframe='true'>       
                       </div> 
                       <div class='fb-like right' 
                       data-href='https://thmeythmey.com/?page=detail&id=63020' data-layout='button_count' data-action='like' data-show-faces='false' data-share='false'>       
                       </div>
                    </div>

                    <div class="block_image_detail left">
                       <div class="left image_slide">
                           <div class="left icon_image_slide">
                               <i class="icon-camera white size14_kh"></i> 
                               <span class="kh size16_kh lineheight30_kh white">រូបភាព</span>
                           </div>
                       </div>
                       <img id='myImg' class='midle effect_over img-responsive' 
                       src='<?php echo base_url();?>public/image.san.com/<?php echo $row['art_feature_img'];?>'  alt='<?php echo $row['art_feature_img_dec'];?>'/>
                       
                       <div class='title_image'>
                           <span class='title_kh size14_kh italic dark lineheight30_kh'> 
                            <?php echo $row['art_feature_img_dec'];?>
                           </span>
                       </div>
                       <div id="myModal" class="modal">
                           <span class="close">&times;</span>
                           <img class="modal-content" id="img01"/>
                           <div id="caption" class="title_kh size15_kh lineheight20_kh white"></div>
                       </div>
                    </div>
                        <div class='detail_desc left'>
                          <span class='left kh size17_kh dark lineheight28_kh'>
                            <?php echo add_path($row['art_detail']);?>
                            
                          </span>
                        </div>                     
                        <!-- <div class='w100 left'>
                            <div class='left en size15_kh lineheight30_kh' style='margin:0px 10px 0px 0;'>Tag: </div>
                            
                            <div onclick="window.open('index60b8.html?page=location&amp;tag=%e1%9e%98%e1%9f%89%e1%9e%98%20%e1%9e%a1%e1%9e%bc%e2%80%8b%e1%9e%9a%e1%9f%89%e1%9e%b6%e2%80%8b')" class='margin-right tag-hover pointer left btn-info btn-block_2 effect_over size14_kh lineheight22_kh title_kh'>
                                <i class='icon-tags'></i>&nbsp;ម៉ម ឡូ​រ៉ា​
                            </div>

                        </div> -->
                        <?php
                        if ($row['resource_title']!='' or $row['resource_url']!=''){
                          ?>
                           <a href="<?php echo $row['resource_url']; ?>" target="_blank">
                            ប្រភពដើម : <?php echo $row['resource_title']; ?>
                        </a>
                       <?php } ?>
                       

                        <div class='waerning size14_kh right title_kh lineheight22_kh'>© រក្សាសិទ្ធិដោយ san.com</div>
                        <div class='detail_dp_counter_ctn kh size12_kh dark_gray lineheight16_kh'>
                            <div class='left share_addthis_button'> 
                                <div class='addthis_toolbox addthis_default_style addthis_20x20_style'>
                                    <a class='addthis_button_twitter'></a>
                                    <a class='addthis_button_google_plusone_share'></a>
                                    <a class='addthis_button_compact'></a> 
                                </div>
                            </div>
                            <div class='fb-share-button right' data-href='https://thmeythmey.com/?page=detail&id=63020&action=share' data-layout='button_count' data-mobile-iframe='true'>        
                            </div>
                            <div class='fb-like right' data-href='https://thmeythmey.com/?page=detail&id=63020' data-layout='button_count' data-action='like' data-show-faces='false' data-share='false'>
                                
                            </div>
                        </div>
                </div>


                <div class="border_block_ad left w100">                 
                    <div class="ad left w100" style="">                                                                                                                                                                 
                        <div id='banner_367' class='ad_banner  right ' onclick="myFunctionClick('367','https://www.facebook.com/sergecomtessesalon/')"><img src='<?php echo base_url();?>public/a.thmeythmey.com/advertise/367/12a1.gif' width='640' height= alt='Serge Comtesse Under Detail Article'  class='img-responsive'/><script type='text/javascript'> impression(367);</script></div>                                          
                    </div>
                </div>   
                     <?php include_once 'news_relate.php';?>                                                                
                </div>                            
            </div>
        </div><!--end lpanel-->
    </div> 

    <?php } ?>