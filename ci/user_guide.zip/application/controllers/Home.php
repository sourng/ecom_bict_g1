<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
	function __construct() 
    { 
        parent::__construct();

        $this->load->helper('form'); 
        $this->load->helper('url');
       $this->load->model('m_crud', '', true);	
 		
    }

	public function index(){
		$data['categories']=$this->m_crud->get_by_sql("SELECT * from tbl_articales_categories");
		$data['feature_big']=$this->m_crud->get_by_sql(
		"SELECT art.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_articales_categories as cat inner join 			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			art.cat_id=cat.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			ORDER BY art.art_id desc
			limit 5"		
		);
		$data['national']=$this->m_crud->get_by_sql(
		"SELECT art.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_articales_categories as cat inner join 			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			art.cat_id=cat.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where art.cat_id=1
			ORDER BY art.art_id desc
			limit 6"		
		);
		$data['enternational']=$this->m_crud->get_by_sql(
		"SELECT art.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_articales_categories as cat inner join 			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			art.cat_id=cat.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where art.cat_id=2
			ORDER BY art.art_id desc
			limit 6"		
		);
		$data['sport']=$this->m_crud->get_by_sql(
		"SELECT art.*,tag.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_categories_tags as tag inner join
			tbl_articales_categories as cat inner join
			tbl_users as users  inner join
			tbl_users_groups as groups on
			art.art_id=tag.art_id and
			cat.cat_id=tag.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where tag.cat_id=3
			order by tag.tag_id desc
			limit 6"		
		);
		$data['popular']=$this->m_crud->get_by_sql(
		"SELECT *
			FROM tbl_articles
			WHERE art_id IN (SELECT *
			                        FROM (SELECT art_id
			                              FROM tbl_articles_views
			                              GROUP BY art_id
			                              HAVING COUNT(art_id) > 10)
			                        AS a) "		
		);
		
		$this->load->view('index',$data);

	}/*End index*/
	
	public function page($id){	
		$data['categories']=$this->m_crud->get_by_sql("SELECT * from tbl_articales_categories");
		$data['page']=$this->m_crud->get_by_sql(
		"SELECT art.*,tag.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_categories_tags as tag inner join
			tbl_articales_categories as cat inner join
			tbl_users as users  inner join
			tbl_users_groups as groups on
			art.art_id=tag.art_id and
			cat.cat_id=tag.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where tag.cat_id=$id
			order by tag.tag_id desc
			limit 15"		
		);
		$data['popular']=$this->m_crud->get_by_sql(
		"SELECT *
			FROM tbl_articles
			WHERE art_id IN (SELECT *
			                        FROM (SELECT art_id
			                              FROM tbl_articles_views
			                              GROUP BY art_id
			                              HAVING COUNT(art_id) > 10)
			                        AS a);"		
		);
		$this->load->view('page',$data);
	}/*End page*/



	public function article($id){
			$data['categories']=$this->m_crud->get_by_sql("SELECT * from tbl_articales_categories");	
			$data['article']=$this->m_crud->get_by_sql(
			"SELECT art.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_articales_categories as cat inner join 			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			art.cat_id=cat.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where art.art_id=".$id			
		);
		$data['count_views']=$this->m_crud->get_by_sql(
		"SELECT count(art_id) as views from 
				tbl_articles_views 
				where art_id=".$id
		);
		$data['popular']=$this->m_crud->get_by_sql(
		"SELECT *
			FROM tbl_articles
			WHERE art_id IN (SELECT *
			                        FROM (SELECT art_id
			                              FROM tbl_articles_views
			                              GROUP BY art_id
			                              HAVING COUNT(art_id) > 10)
			                        AS a) and art_id<>".$id		
		);
			$this->load->view('article',$data);
		}/*End article*/


	public function search(){	
			
			$this->load->view('search');
		}/*End search*/

	public function author($id){
		$data['categories']=$this->m_crud->get_by_sql("SELECT * from tbl_articales_categories");	
		$data['users']=$this->m_crud->get_by_sql(
		"SELECT * from			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			users.group_id=groups.group_id
			where user_id=".$id		
		);
		$data['article']=$this->m_crud->get_by_sql(
			"SELECT art.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_articales_categories as cat inner join 			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			art.cat_id=cat.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where art.user_id=".$id
		);	

		$data['allcount']=$this->m_crud->get_by_sql(
			"SELECT count(*) as count from
			tbl_articles 
			where user_id=".$id
		);
		$data['popular']=$this->m_crud->get_by_sql(
		"SELECT *
			FROM tbl_articles
			WHERE art_id IN (SELECT *
			                        FROM (SELECT art_id
			                              FROM tbl_articles_views
			                              GROUP BY art_id
			                              HAVING COUNT(art_id) > 10)
			                        AS a);"		
		);	
			$this->load->view('author',$data);
		}/*End author*/


	public function print($id){				
		$data['article']=$this->m_crud->get_by_sql(
			"SELECT art.*,cat.*,users.*,groups.* from
			tbl_articles as art inner join
			tbl_articales_categories as cat inner join 			
			tbl_users as users inner join
			tbl_users_groups as groups on 
			art.cat_id=cat.cat_id and
			art.user_id=users.user_id and 
			users.group_id=groups.group_id
			where art.art_id=".$id			
		);
		$data['count_views']=$this->m_crud->get_by_sql(
		"SELECT count(art_id) as views from 
				tbl_articles_views 
				where art_id=".$id
		);
			$this->load->view('print',$data);
		
		}/*End Print*/
	


}/*End Class Home*/
?>